from __future__ import annotations

import hashlib
import io
import re
from collections.abc import Iterable
from typing import TypeVar

from pydantic import BaseModel
from pypdf import PdfReader

from .models import DocumentChunk, SourceReference


class DocumentError(ValueError):
    pass


T = TypeVar("T", bound=BaseModel)
_TOC_PAGE_NUMBER = re.compile(r"\.{5,}\s*(?:[A-Z]+-)?\d+\b", re.IGNORECASE)


def normalize_text(text: str) -> str:
    return " ".join(text.split())


def _evidence_key(text: str) -> str:
    # Preserve operators, signs, decimals, units and negation in exact quotes.
    return normalize_text(text)


def extract_pages(pdf_bytes: bytes) -> list[tuple[int, str]]:
    try:
        reader = PdfReader(io.BytesIO(pdf_bytes))
    except Exception as error:
        raise DocumentError("The uploaded file is not a readable PDF.") from error
    if reader.is_encrypted:
        raise DocumentError("Encrypted PDFs are not supported.")
    try:
        return [
            (number, page.extract_text() or "")
            for number, page in enumerate(reader.pages, 1)
        ]
    except Exception as error:
        raise DocumentError("PDF text extraction failed.") from error


def _section_heading(raw_text: str) -> str:
    for line in raw_text.splitlines():
        candidate = normalize_text(line)
        if 3 <= len(candidate) <= 100 and (
            candidate.isupper() or re.match(r"^\d+(?:\.\d+)*\s+\S", candidate)
        ):
            return candidate
    return ""


def _is_table_of_contents(raw_text: str) -> bool:
    return (
        "table of contents" in normalize_text(raw_text).casefold()
        or len(_TOC_PAGE_NUMBER.findall(raw_text)) >= 3
    )


def _pieces(text: str, max_chars: int) -> Iterable[str]:
    start = 0
    while start < len(text):
        end = min(start + max_chars, len(text))
        if end == len(text):
            yield text[start:end]
            return
        cut = text.rfind(" ", start, end + 1)
        end = cut if cut > start else end
        yield text[start:end]
        start = end


def chunk_pages(
    pages: Iterable[tuple[int, str]], max_chars: int = 6_000
) -> list[DocumentChunk]:
    if max_chars < 1:
        raise ValueError("max_chars must be positive")
    chunks: list[DocumentChunk] = []
    for page_number, raw_text in pages:
        if _is_table_of_contents(raw_text):
            continue
        text = normalize_text(raw_text)
        if not text:
            continue
        section = _section_heading(raw_text)
        pieces = filter(None, map(normalize_text, _pieces(text, max_chars)))
        for sequence, piece in enumerate(pieces, 1):
            digest = hashlib.sha256(piece.encode("utf-8")).hexdigest()
            chunks.append(
                DocumentChunk(
                    chunk_id=f"p{page_number:04d}-c{sequence:03d}-{digest[:12]}",
                    page_number=page_number,
                    section=section,
                    text=piece,
                    content_hash=digest,
                )
            )
    if not chunks:
        raise DocumentError("PDF contains insufficient extractable text.")
    return chunks


def parse_pdf(pdf_bytes: bytes, max_chars: int = 6_000) -> list[DocumentChunk]:
    return chunk_pages(extract_pages(pdf_bytes), max_chars=max_chars)


def verify_source_reference(
    reference: SourceReference, chunks: list[DocumentChunk]
) -> bool:
    chunk = next((item for item in chunks if item.chunk_id == reference.chunk_id), None)
    excerpt = _evidence_key(reference.excerpt)
    return bool(
        excerpt
        and chunk
        and chunk.page_number == reference.page_number
        and excerpt in _evidence_key(chunk.text)
    )


def canonicalize_source_references(
    value: T,
    chunks: list[DocumentChunk],
    *,
    repair_excerpt: bool = True,
    strict: bool = False,
) -> T:
    data = value.model_dump(mode="json")
    chunks_by_id = {chunk.chunk_id: chunk for chunk in chunks}

    def visit(node: object) -> None:
        if isinstance(node, list):
            for item in node:
                visit(item)
        elif isinstance(node, dict):
            if {"chunk_id", "page_number", "excerpt"} <= node.keys():
                if strict:
                    chunk = chunks_by_id.get(str(node["chunk_id"]))
                    words = _evidence_key(str(node["excerpt"])).split()
                    if (
                        chunk is None
                        or not 5 <= len(words) <= 25
                        or " ".join(words) not in _evidence_key(chunk.text)
                    ):
                        raise DocumentError(
                            "Source references must cite an exact 5-to-25-word "
                            "excerpt from an assigned chunk."
                        )
                excerpt = _evidence_key(str(node["excerpt"]))
                matches = [
                    chunk
                    for chunk in chunks
                    if excerpt and excerpt in _evidence_key(chunk.text)
                ]
                if matches:
                    chunk = next(
                        (item for item in matches if item.chunk_id == node["chunk_id"]),
                        matches[0] if len(matches) == 1 else None,
                    )
                    if chunk is not None:
                        node.update(
                            chunk_id=chunk.chunk_id,
                            page_number=chunk.page_number,
                            section=chunk.section,
                        )
                # An unmatched quote stays invalid, even when repair_excerpt=True.
                # Fuzzy rewriting can change the claim without fixing the artifact.
            for item in node.values():
                visit(item)

    visit(data)
    return type(value).model_validate(data)


def render_chunks(chunks: Iterable[DocumentChunk]) -> str:
    return "\n\n".join(
        f"[{item.chunk_id} | page {item.page_number} | {item.section}]\n{item.text}"
        for item in chunks
    )
