from __future__ import annotations

from enum import StrEnum
from typing import Literal, Self

from pydantic import (
    AwareDatetime,
    BaseModel,
    ConfigDict,
    Field,
    JsonValue,
    field_validator,
    model_validator,
)


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


def _nonblank(value: str) -> str:
    if not value.strip():
        raise ValueError("must not be blank")
    return value


class ActivityEvent(str):
    """A display-safe progress update that remains compatible with text callbacks."""

    def __new__(
        cls,
        message: str,
        *,
        agent: str = "",
        role: str = "",
        model: str = "",
        state: str = "",
        task: str = "",
        scope: str = "",
        deliverable: str = "",
        artifact: BaseModel | None = None,
        artifact_label: str = "",
    ) -> "ActivityEvent":
        event = super().__new__(cls, message)
        event.agent = agent
        event.role = role
        event.model = model
        event.state = state
        event.task = task
        event.scope = scope
        event.deliverable = deliverable
        event.artifact = artifact
        event.artifact_label = artifact_label
        return event


class RequirementType(StrEnum):
    FUNCTIONAL = "functional"
    NON_FUNCTIONAL = "non_functional"
    BUSINESS = "business"


class RequirementPriority(StrEnum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class ScenarioType(StrEnum):
    POSITIVE = "positive"
    NEGATIVE = "negative"
    BOUNDARY = "boundary"
    EDGE = "edge"
    STATE_TRANSITION = "state_transition"


class TestPriority(StrEnum):
    P1 = "P1"
    P2 = "P2"
    P3 = "P3"


class RunType(StrEnum):
    SINGLE_PROMPT = "single_prompt"
    STAGED_SINGLE_AGENT = "staged_single_agent"
    CENTRALIZED_MULTI_AGENT = "centralized_multi_agent"


class RunStatus(StrEnum):
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class FailureCategory(StrEnum):
    PARSING = "parsing"
    CONFIGURATION = "configuration"
    PROVIDER_REJECTION = "provider_rejection"
    TRANSPORT_EXHAUSTION = "transport_exhaustion"
    TIMEOUT = "timeout"
    BUDGET_EXHAUSTION = "budget_exhaustion"
    SCHEMA_FAILURE = "schema_failure"
    SEMANTIC_VALIDATION = "semantic_validation"


class AgentSetup(StrictModel):
    agent: Literal[
        "analyst",
        "test_generator",
        "reviewer",
        "coverage_analyzer",
        "scout",
        "curator",
        "scenario_architect",
        "test_writer",
        "critic",
    ]
    role: str = Field(min_length=1, max_length=120)
    instructions: str = Field(default="", max_length=4_000)


def default_agent_setups() -> dict[str, AgentSetup]:
    return {
        "analyst": AgentSetup(agent="analyst", role="Requirement analyst"),
        "test_generator": AgentSetup(agent="test_generator", role="Test designer"),
        "reviewer": AgentSetup(agent="reviewer", role="Requirements curator"),
        "coverage_analyzer": AgentSetup(
            agent="coverage_analyzer", role="Coverage analyst"
        ),
        "scout": AgentSetup(agent="scout", role="Evidence scout"),
        "curator": AgentSetup(agent="curator", role="Requirement curator"),
        "scenario_architect": AgentSetup(
            agent="scenario_architect", role="Scenario architect"
        ),
        "test_writer": AgentSetup(agent="test_writer", role="Test writer"),
        "critic": AgentSetup(agent="critic", role="Artifact critic"),
    }


class SourceReference(StrictModel):
    chunk_id: str = Field(min_length=1)
    page_number: int = Field(ge=1)
    section: str = ""
    excerpt: str = Field(min_length=1)


class DocumentChunk(StrictModel):
    chunk_id: str = Field(min_length=1)
    page_number: int = Field(ge=1)
    section: str = ""
    text: str = Field(min_length=1)
    content_hash: str = Field(pattern=r"^[0-9a-f]{64}$")


class Requirement(StrictModel):
    requirement_id: str = Field(pattern=r"^REQ-\d{3,}$")
    title: str = Field(min_length=1)
    description: str = Field(min_length=1)
    requirement_type: RequirementType
    module: str = Field(min_length=1)
    priority: RequirementPriority
    ambiguities: list[str] = Field(default_factory=list)
    dependency_ids: list[str] = Field(default_factory=list)
    source_references: list[SourceReference] = Field(min_length=1)


class CandidateRequirement(StrictModel):
    candidate_id: str = Field(pattern=r"^CAND-\d{3,}-\d{3,}$")
    title: str = Field(min_length=1)
    description: str = Field(min_length=1)
    requirement_type: RequirementType
    module: str = Field(min_length=1)
    priority: RequirementPriority
    ambiguities: list[str] = Field(default_factory=list)
    source_references: list[SourceReference] = Field(min_length=1)


class Scenario(StrictModel):
    scenario_id: str = Field(pattern=r"^SCN-\d{3,}$")
    title: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    scenario_type: ScenarioType
    preconditions: list[str] = Field(default_factory=list)
    requirement_ids: list[str] = Field(min_length=1)
    source_references: list[SourceReference] = Field(min_length=1)


class TestStep(StrictModel):
    step_number: int = Field(ge=1)
    action: str = Field(min_length=1)
    expected_result: str = Field(min_length=1)


class TestCase(StrictModel):
    test_case_id: str = Field(pattern=r"^TC-\d{3,}$")
    scenario_id: str = Field(pattern=r"^SCN-\d{3,}$")
    requirement_ids: list[str] = Field(min_length=1)
    title: str = Field(min_length=1)
    priority: TestPriority
    preconditions: list[str] = Field(default_factory=list)
    test_data: dict[str, JsonValue] = Field(default_factory=dict)
    steps: list[TestStep] = Field(min_length=1)
    source_references: list[SourceReference] = Field(min_length=1)


class ArtifactBundle(StrictModel):
    requirements: list[Requirement]
    scenarios: list[Scenario]
    test_cases: list[TestCase]


class ArtifactPatch(StrictModel):
    requirements: list[Requirement] = Field(default_factory=list)
    scenarios: list[Scenario] = Field(default_factory=list)
    test_cases: list[TestCase] = Field(default_factory=list)


class RepairVerification(StrictModel):
    resolved_finding_ids: list[str]
    unresolved_finding_ids: list[str]
    reasons: dict[str, str] = Field(description="One source-backed explanation per finding ID; identify the relevant artifact and what remains wrong or proves resolution.")


class RequirementBatch(StrictModel):
    requirements: list[Requirement]


class CandidateRequirementBatch(StrictModel):
    candidates: list[CandidateRequirement]


class RequirementDecisionAction(StrEnum):
    RETAIN = "retain"
    MERGE = "merge"
    REJECT = "reject"


class RequirementDecision(StrictModel):
    candidate_id: str = Field(pattern=r"^CAND-\d{3,}-\d{3,}$")
    action: RequirementDecisionAction
    canonical_requirement_id: str | None = Field(default=None, pattern=r"^REQ-\d{3,}$")
    reason: str = Field(min_length=1)

    @model_validator(mode="after")
    def validate_canonical_requirement_id(self) -> Self:
        if self.action is RequirementDecisionAction.REJECT:
            if self.canonical_requirement_id is not None:
                raise ValueError("rejected candidates cannot have a canonical requirement ID")
        elif self.canonical_requirement_id is None:
            raise ValueError("retained and merged candidates require a canonical requirement ID")
        return self


class RequirementAssignment(StrictModel):
    candidate_id: str = Field(pattern=r"^CAND-\d{3,}-\d{3,}$")
    canonical_requirement_id: str | None = Field(default=None, pattern=r"^REQ-\d{3,}$")
    reason_code: Literal["distinct", "duplicate", "unsupported", "non_testable"]


class RequirementAssignmentBatch(StrictModel):
    assignments: list[RequirementAssignment]


class RequirementSynthesis(StrictModel):
    decisions: list[RequirementDecision]
    requirements: list[Requirement]


class ScenarioBatch(StrictModel):
    scenarios: list[Scenario]


class TestCaseBatch(StrictModel):
    test_cases: list[TestCase]


class GeneratedCases(StrictModel):
    scenarios: list[Scenario]
    test_cases: list[TestCase]


class CoverageAssignment(StrictModel):
    requirement_id: str = Field(pattern=r"^REQ-\d{3,}$")
    scenario_id: str = Field(pattern=r"^SCN-\d{3,}$")
    test_case_id: str = Field(pattern=r"^TC-\d{3,}$")


class CoverageRepair(StrictModel):
    assignments: list[CoverageAssignment] = Field(min_length=1)


class ReviewIssue(StrictModel):
    artifact_id: str
    reason: str


class ReviewResult(StrictModel):
    accepted: bool
    issues: list[ReviewIssue] = Field(default_factory=list)


class CriticSeverity(StrEnum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class CriticFinding(StrictModel):
    finding_id: str = Field(pattern=r"^FIND-\d{3,}$")
    severity: CriticSeverity
    finding_type: str = Field(min_length=1)
    artifact_ids: list[str] = Field(min_length=1)
    responsible_role: Literal["curator", "scenario_architect", "test_writer"]
    repair_kind: Literal["citation", "relationship", "semantic"] = "semantic"
    required_action: str = Field(min_length=1)
    source_references: list[SourceReference] = Field(min_length=1)


class CriticReport(StrictModel):
    accepted: bool
    findings: list[CriticFinding] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_findings(self) -> Self:
        if len({f.finding_id for f in self.findings}) != len(self.findings):
            raise ValueError("finding IDs must be unique")
        if self.accepted and self.findings:
            raise ValueError("accepted reports cannot contain findings")
        if not self.accepted and not self.findings:
            raise ValueError("rejected reports require at least one finding")
        return self


class AgentStageOutput(StrictModel):
    stage: Literal[
        "scout", "source_audit", "curator", "scenario_architect", "test_writer", "critic", "repair", "catalog", "evaluation", "generation", "requirements", "scenarios", "test_cases"
    ]
    task_index: int = Field(ge=0)
    role: str = Field(min_length=1)
    input_ids: list[str] = Field(default_factory=list)
    fingerprint: str = ""
    reused_from: str | None = None
    output: dict[str, JsonValue]
    created_at: AwareDatetime

    def order_key(self) -> tuple[int, int]:
        stages = (
            "scout", "source_audit", "curator", "scenario_architect", "test_writer", "critic", "repair", "catalog", "evaluation", "generation", "requirements", "scenarios", "test_cases"
        )
        if self.stage == "critic" and "resolved_finding_ids" in self.output:
            return len(stages), self.task_index
        return stages.index(self.stage), self.task_index


class ValidationIssue(StrictModel):
    code: str
    artifact_id: str
    message: str


class ValidationReport(StrictModel):
    valid: bool
    issues: list[ValidationIssue]
    uncovered_requirement_ids: list[str]
    orphan_scenario_ids: list[str]
    orphan_test_case_ids: list[str]


class RTMRow(StrictModel):
    requirement_id: str
    scenario_ids: list[str]
    test_case_ids: list[str]
    source_chunk_ids: list[str]
    covered: bool


class RunMetrics(StrictModel):
    completion: bool
    schema_valid: bool
    citation_coverage: float = Field(ge=0, le=1)
    requirement_scenario_coverage: float = Field(ge=0, le=1)
    requirement_test_case_coverage: float = Field(ge=0, le=1)
    positive_scenario_coverage: float = Field(ge=0, le=1)
    non_positive_scenario_coverage: float = Field(ge=0, le=1)
    rtm_completeness: float = Field(ge=0, le=1)
    orphan_rate: float = Field(ge=0, le=1)
    invalid_reference_rate: float = Field(ge=0, le=1)
    duplicate_test_case_rate: float = Field(ge=0, le=1)
    requirement_count: int = Field(ge=0)
    scenario_count: int = Field(ge=0)
    test_case_count: int = Field(ge=0)
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    charged_tokens: int = Field(default=0, ge=0)
    latency_seconds: float = Field(ge=0)
    retries: int = Field(ge=0)
    schema_repairs: int = Field(ge=0)
    semantic_revisions: int = Field(ge=0)
    budget_exhausted: bool


class RunManifest(StrictModel):
    run_id: str = Field(min_length=1)
    source_filename: str = Field(min_length=1)
    document_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    run_type: RunType
    status: RunStatus
    provider: str = Field(min_length=1)
    model: str = Field(min_length=1)
    temperature: float = Field(ge=0)
    token_ceiling: int = Field(ge=1)
    prompt_version: str = Field(min_length=1)
    schema_version: str = Field(min_length=1)
    configuration: dict[str, JsonValue] = Field(default_factory=dict)
    started_at: AwareDatetime
    completed_at: AwareDatetime | None = None
    failure_category: FailureCategory | None = None
    failure_message: str | None = None

    @model_validator(mode="after")
    def validate_status(self) -> Self:
        if self.completed_at is not None and self.completed_at < self.started_at:
            raise ValueError("completed_at cannot be earlier than started_at")
        if self.status is RunStatus.COMPLETED:
            if self.completed_at is None:
                raise ValueError("completed runs require completed_at")
            if self.failure_category is not None or self.failure_message is not None:
                raise ValueError("completed runs cannot have failure details")
        elif self.status is RunStatus.FAILED:
            if self.completed_at is None or self.failure_category is None:
                raise ValueError("failed runs require completed_at and failure_category")
        elif any(
            value is not None
            for value in (self.completed_at, self.failure_category, self.failure_message)
        ):
            raise ValueError("running runs cannot have terminal fields")
        return self


class CallAttempt(StrictModel):
    call_id: str
    phase: Literal["generation", "catalog", "evaluation"]
    stage: str
    task_index: int = Field(ge=0)
    attempt: int = Field(ge=1)
    model: str
    provider: str
    schema_name: str
    request_hash: str
    schema_hash: str
    max_output_tokens: int = Field(ge=1)
    input_tokens: int | None = Field(default=None, ge=0)
    output_tokens: int | None = Field(default=None, ge=0)
    reported_total_tokens: int | None = Field(default=None, ge=0)
    budget_tokens: int = Field(default=0, ge=0)
    estimated_tokens: int = Field(default=0, ge=0)
    usage: dict[str, JsonValue] = Field(default_factory=dict)
    provider_request_id: str | None = None
    finish_reason: str | None = None
    status: Literal["completed", "failed", "blocked"]
    error: str = ""
    response_excerpt: str = ""
    started_at: AwareDatetime
    latency_seconds: float = Field(ge=0)


class RunDiagnostics(StrictModel):
    evidence_version: str = ""
    evidence_spans: list[dict[str, JsonValue]] = Field(default_factory=list)
    source_dispositions: list[dict[str, JsonValue]] = Field(default_factory=list)
    recovery_parent_id: str | None = None
    inherited_budget_tokens: int = Field(default=0, ge=0)
    reused_tasks: int = Field(default=0, ge=0)
    semantic_status: Literal["not_reviewed", "accepted", "unresolved"] = "not_reviewed"
    unresolved_findings: list[CriticFinding] = Field(default_factory=list)
    evaluation_error: str = ""


class RunResult(StrictModel):
    manifest: RunManifest
    call_attempts: list[CallAttempt] = Field(default_factory=list)
    diagnostics: RunDiagnostics | None = None
    stage_outputs: list[AgentStageOutput] = Field(default_factory=list)
    bundle: ArtifactBundle | None = None
    validation: ValidationReport | None = None
    rtm: list[RTMRow] = Field(default_factory=list)
    metrics: RunMetrics | None = None
    coverage: CoverageScore | None = None
    coverage_evaluation: CoverageEvaluation | None = None

    def download_bundle(self) -> dict[str, JsonValue]:
        bundle = self.bundle
        return {
            "manifest": self.manifest.model_dump(mode="json"),
            "call_attempts": [item.model_dump(mode="json") for item in self.call_attempts],
            "diagnostics": self.diagnostics.model_dump(mode="json") if self.diagnostics else None,
            "requirements": (
                [item.model_dump(mode="json") for item in bundle.requirements]
                if bundle
                else []
            ),
            "scenarios": (
                [item.model_dump(mode="json") for item in bundle.scenarios] if bundle else []
            ),
            "test_cases": (
                [item.model_dump(mode="json") for item in bundle.test_cases]
                if bundle
                else []
            ),
            "validation": self.validation.model_dump(mode="json") if self.validation else None,
            "rtm": [item.model_dump(mode="json") for item in self.rtm],
            "metrics": self.metrics.model_dump(mode="json") if self.metrics else None,
            "coverage": self.coverage.model_dump(mode="json") if self.coverage else None,
            "coverage_evaluation": (
                self.coverage_evaluation.model_dump(mode="json")
                if self.coverage_evaluation
                else None
            ),
        }


class CoverageCatalogStatus(StrEnum):
    MACHINE_FROZEN = "machine_frozen"
    APPROVED = "approved"
    SUPERSEDED = "superseded"


class CoverageEvaluationStatus(StrEnum):
    COMPLETED = "completed"
    FAILED = "failed"


class HumanRatingDimension(StrEnum):
    COVERAGE = "coverage"
    GROUNDEDNESS = "groundedness"
    EXECUTABILITY = "executability"
    REDUNDANCY_CONTROL = "redundancy_control"


class CoverageUnit(StrictModel):
    unit_id: str = Field(pattern=r"^CU-\d{3,}$")
    title: str = Field(min_length=1)
    description: str = Field(min_length=1)
    unit_type: str = Field(min_length=1)
    source_references: list[SourceReference] = Field(min_length=1)


class CoverageCatalog(StrictModel):
    catalog_id: str = Field(min_length=1)
    document_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    evaluator_version: str = Field(min_length=1)
    status: CoverageCatalogStatus
    units: list[CoverageUnit] = Field(min_length=1)
    created_at: AwareDatetime
    approved_at: AwareDatetime | None = None

    _validate_nonblank = field_validator("catalog_id", "evaluator_version")(_nonblank)

    @model_validator(mode="after")
    def validate_status(self) -> Self:
        if len({unit.unit_id for unit in self.units}) != len(self.units):
            raise ValueError("duplicate coverage unit IDs are not allowed")
        if self.status is CoverageCatalogStatus.APPROVED:
            if self.approved_at is None:
                raise ValueError("approved catalogs require approved_at")
        elif self.approved_at is not None:
            raise ValueError("non-approved catalogs cannot have approved_at")
        return self


class CoverageUnitBatch(StrictModel):
    units: list[CoverageUnit]


class CoverageMappingEntry(StrictModel):
    test_case_id: str = Field(pattern=r"^TC-\d{3,}$")
    covered_unit_ids: list[str] = Field(default_factory=list)


class CoverageMappingBatch(StrictModel):
    mappings: list[CoverageMappingEntry]


class CoverageScore(StrictModel):
    catalog_id: str = Field(min_length=1)
    precision: float = Field(ge=0, le=1)
    recall: float = Field(ge=0, le=1)
    f1: float = Field(ge=0, le=1)
    true_positive_count: int = Field(ge=0)
    false_positive_count: int = Field(ge=0)
    false_negative_count: int = Field(ge=0)
    total_coverage_units: int = Field(ge=0)
    total_test_cases: int = Field(ge=0)
    uncovered_unit_ids: list[str] = Field(default_factory=list)
    unmapped_test_case_ids: list[str] = Field(default_factory=list)

    _validate_nonblank = field_validator("catalog_id")(_nonblank)


class CoverageEvaluation(StrictModel):
    run_id: str = Field(min_length=1)
    catalog_id: str = Field(min_length=1)
    status: CoverageEvaluationStatus
    mappings: CoverageMappingBatch | None = None
    score: CoverageScore | None = None
    error: str = Field(default="", max_length=2_000)
    evaluated_at: AwareDatetime

    _validate_nonblank = field_validator("run_id", "catalog_id")(_nonblank)

    @model_validator(mode="after")
    def validate_status(self) -> Self:
        if self.status is CoverageEvaluationStatus.COMPLETED:
            if self.mappings is None or self.score is None or self.error:
                raise ValueError("completed evaluations require mappings and score with blank error")
            if self.score.catalog_id != self.catalog_id:
                raise ValueError("score catalog_id must match evaluation catalog_id")
        elif self.mappings is not None or self.score is not None or not self.error.strip():
            raise ValueError("failed evaluations require no mappings or score and nonblank error")
        return self


class HumanRating(StrictModel):
    rating_id: str = Field(min_length=1)
    run_id: str = Field(min_length=1)
    rater_id: str = Field(min_length=1, max_length=120)
    dimension: HumanRatingDimension
    score: int = Field(ge=1, le=4)
    reason: str = Field(default="", max_length=2_000)
    rubric_version: str = Field(min_length=1)
    round: int = Field(default=1, ge=1)
    created_at: AwareDatetime

    _validate_nonblank = field_validator(
        "rating_id", "run_id", "rater_id", "rubric_version"
    )(_nonblank)


class HumanAdjudication(StrictModel):
    adjudication_id: str = Field(min_length=1)
    run_id: str = Field(min_length=1)
    dimension: HumanRatingDimension
    score: int = Field(ge=1, le=4)
    reason: str = Field(min_length=1, max_length=2_000)
    rubric_version: str = Field(min_length=1)
    created_at: AwareDatetime

    _validate_nonblank = field_validator(
        "adjudication_id", "run_id", "reason", "rubric_version"
    )(_nonblank)


class HumanCoverageRating(StrictModel):
    run_id: str = Field(min_length=1)
    human_score: int = Field(ge=1, le=4)
    judge_score: int = Field(ge=1, le=4)
    judge_f1: float = Field(ge=0, le=1)
    reason: str = Field(default="", max_length=2_000)
    rubric_version: str = Field(min_length=1)
    created_at: AwareDatetime


class RunHistoryItem(StrictModel):
    run_id: str
    source_filename: str
    run_type: RunType
    status: RunStatus
    provider: str
    model: str
    started_at: AwareDatetime
    completed_at: AwareDatetime | None
    requirement_count: int | None = None
    scenario_count: int | None = None
    test_case_count: int | None = None

    @property
    def display_status(self) -> str:
        return "Interrupted" if self.status is RunStatus.RUNNING else self.status.value.title()
