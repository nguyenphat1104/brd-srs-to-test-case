# Suite 2dbe0dfc4d67a3fa

Source: D001

Review the supplied artifacts as they stand. Missing sections remain missing; do not infer tests from requirements alone.

## Requirements (92)

### REQ-001: Model Manager Software Tool Scope and Job Capabilities

**Description:** The Model Manager (MM) software tool must allow the user to configure, schedule, run, monitor, and stop (as well as re-start/resume) model jobs.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: NSAP project sponsors and management. 1.4 Project Scope The Model Manager is a software tool that will allow the user to configure, schedule, run, monitor,

### REQ-002: Model Back End Extension and Job Automation

**Description:** The Model Manager system must extend the current model back end system and automate the setup, running, and monitoring of model jobs, including a more automated node management system.

**Requirement Type:** functional

**Module:** Model Manager / Back End

**Priority:** medium

**Source evidence**

- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: and stop (and re-start /resume) model jobs. The primary goal of this project is to extend the current model back end system and to automate
- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: the setup, running and monitoring of model jobs. This will include a more automated node management system. 1.5 References [1] “4DWX on the Move (4DWX

### REQ-003: Stand-alone and MetVault Co-execution

**Description:** The MM must be capable of running as a stand-alone software tool with no knowledge of MetVault, as well as running in conjunction with MetVault (and as part of the 4DWX OTM system).

**Requirement Type:** functional

**Module:** Model Manager / Deployment

**Priority:** medium

**Source evidence**

- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: to the current model back end. The MM is a stand- alone software tool, which will also be part of the 4DWX OTM system (see
- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: Functional Requirements Specification for the Model Manager Page 3 The MM can run in conjunction with the MetVault, and it can also run as a
- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: stand-alone application with no knowledge about a MetVault. The MM will be accessible from a web-based GUI and a command line tool. 2.2 Product Features

### REQ-004: User Access Interfaces

**Description:** The MM must be accessible from a web-based GUI and a command line tool.

**Requirement Type:** functional

**Module:** Model Manager / User Interface

**Priority:** high

**Source evidence**

- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: [1]). Command Line ToolModel ManagerMetVault Web-based GUI
- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: stand-alone application with no knowledge about a MetVault. The MM will be accessible from a web-based GUI and a command line tool. 2.2 Product Features

### REQ-005: Job Submission Options

**Description:** The system must allow users to submit a 'by-hand' job or a job defined by a configuration file.

**Requirement Type:** functional

**Module:** Model Manager / Job Management

**Priority:** high

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: view the status of operational model runs, stop and restart existing jobs or set up and start a 'standard' model job. Submit a 'by-hand' job

### REQ-006: Retrieve Saved Job Configuration

**Description:** The system must allow users to retrieve a previously saved job configuration.

**Requirement Type:** functional

**Module:** Model Manager / Job Configuration

**Priority:** medium

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a

### REQ-007: Stop Running Job

**Description:** The system must allow users to stop a running job.

**Requirement Type:** functional

**Module:** Model Manager / Job Control

**Priority:** high

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a

### REQ-008: Start Job (Restart / Resume)

**Description:** The system must allow users to start a job, including restarting or resuming an existing job.

**Requirement Type:** functional

**Module:** Model Manager / Job Control

**Priority:** high

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a

### REQ-009: Change and Save Job Configuration

**Description:** The system must allow users to change and save a job configuration.

**Requirement Type:** functional

**Module:** Model Manager / Job Configuration

**Priority:** medium

**Ambiguities:** ["Marked as optional in source feature diagram."]

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a
- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: job configuration (optional) Set up a new model or “post- processing” job Monitor running jobs

### REQ-010: Setup New Model or Post-processing Job

**Description:** The system must allow users to set up a new model job or a 'post-processing' job.

**Requirement Type:** functional

**Module:** Model Manager / Job Management

**Priority:** high

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: job configuration (optional) Set up a new model or “post- processing” job Monitor running jobs

### REQ-011: Monitor Running Jobs

**Description:** The system must allow users to monitor running jobs.

**Requirement Type:** functional

**Module:** Model Manager / Job Monitoring

**Priority:** high

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: job configuration (optional) Set up a new model or “post- processing” job Monitor running jobs

### REQ-012: MM cluster allocation and decision making

**Description:** The Model Manager (MM) shall manage jobs on one or more clusters, providing node allocation, management, utilization, and decision-making on which cluster(s) a submitted job will run on.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: MM will manage jobs on one or more clusters. Node allocation, management and utilization will be provided by the MM (SRS note: The MM provides
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: many and which clusters a MM is managing. S/he will submit a job to the MM and the MM will make the decision on what

### REQ-013: User option to specify target cluster for job submission

**Description:** The MM shall provide the user with the option to specify what specific cluster his/her job should run on when submitting customized jobs.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** medium

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: the user will need to have the option to specify what cluster his/her job should run on. Managing more than one cluster, will also allow
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: may choose a cluster where the job should run on. 3. User decides what model should be used: MM5 or WRF. 4. User defines a

### REQ-014: Cross-cluster execution for RTFDDA and climoFDDA ensembles

**Description:** The system shall allow RTFDDA and climoFDDA ensembles to run across several clusters.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** medium

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: the user will need to have the option to specify what cluster his/her job should run on. Managing more than one cluster, will also allow
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: RTFDDA and climoFDDA ensembles to run across several clusters. Once a user is logged in into the system, s/he will be presented with the features

### REQ-015: User main menu feature options

**Description:** Once logged in, the system shall present the user with features to: Submit a new job, Retrieve saved job configurations, and View the job queue/monitor running jobs.

**Requirement Type:** functional

**Module:** User Interface

**Priority:** high

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: RTFDDA and climoFDDA ensembles to run across several clusters. Once a user is logged in into the system, s/he will be presented with the features
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: in 2.2: • Submit a new job • Retrieve saved job configurations • View the job queue/monitor running jobs A new job can be submitted

### REQ-016: Methods for submitting a new job to MM

**Description:** The MM shall allow a user to submit a new job via four ways: setting up a new model or 'post-processing' job through the Job-Setup module and submitting it; submitting a 'by-hand' job; submitting a job configuration file; or retrieving, changing, and re-submitting a previously saved job configuration.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** high

**Ambiguities:** ["Terminology for submission options is noted as subject to change."]

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: in 2.2: • Submit a new job • Retrieve saved job configurations • View the job queue/monitor running jobs A new job can be submitted
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: to the MM four different ways: • The user can set up a new model or 'post-processing' job through the Job-Setup module and submit it
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: (3.1 and 3.2). • The user can submit a 'by-hand' job (3.3). • The user can submit a job by supplying a job configuration file
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: to the MM (3.4). • The user can retrieve a job configuration that was previously saved with the MM, change it and re-submit that job
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: (3.5). If the user chooses to submit a new job, s/he will be given the following options to choose from: • “Setup a new model

### REQ-017: Model job type options

**Description:** When choosing to set up a new model job, the MM shall present the user with two options: 'Weather FDDA' and 'Climo'.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** medium

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: MM's Job-Setup module. Suppose the user is logged on to the system and has made the following choices “Submit a new job” -&gt; “Set up
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: a new model job”. S/he is then presented with two more options: “ Weather FDDA” and “Climo”. Use Case “WeatherFDDA”: Setting up a real time

### REQ-018: Submission method for RTFDDA ensemble jobs

**Description:** The MM shall accept RTFDDA ensemble jobs submitted as 'by hand' jobs or through a job configuration file.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** medium

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: case describes the set up of GMOD jobs, re-runs and case studies. At this point, RTFDDA ensemble jobs will be submitted to the MM as
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: 'by hand' jobs or through a job configuration file. The MM will provide a default GMOD job configuration, which can be changed by the user

### REQ-019: Default and custom GMOD job configuration support

**Description:** The MM shall provide a default GMOD job configuration that can be modified by the user, and shall accept and run custom GMOD jobs setup through the Job-Setup module that substitute defaults (such as user-supplied input data, pre-processors, or customized MM5 executables) and allow saving the custom configuration.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** high

**Ambiguities:** ["Defaults for a GMOD job are marked TBD."]

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: 'by hand' jobs or through a job configuration file. The MM will provide a default GMOD job configuration, which can be changed by the user
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: (TBD: Define the defaults for a GMOD job). It is important to note that the model manager will accept and run “custom” GMOD jobs. These
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: are jobs that are also set up through the Setup-module, but do not use the default GMOD configuration For a “custom” GMOD job, e.g., the
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: user may choose to supply his/her own input data, own pre-processors or a customized version of a MM5 executable.
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: Functional Requirements Specification for the Model Manager Page 5 MM's Job-Setup module will allow the user to substitute the default configuration, but it is the
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: “custom” GMOD job thought the Job-Setup module will allow the user to save the job's configuration with the MM. Primary actor: Meteorologist, software engineer Goal:

### REQ-020: Model selection for Weather FDDA job

**Description:** During Weather FDDA job set up, the system shall allow the user to select whether the model to be used is MM5 or WRF.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** high

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: Set up and run a real time and off-line GMOD job Action Sequence: 1. User chooses to “Set up a Weather FDDA Job”. 2. User
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: may choose a cluster where the job should run on. 3. User decides what model should be used: MM5 or WRF. 4. User defines a

### REQ-021: JOBID definition

**Description:** During Weather FDDA job set up, the system shall require/allow the user to define a JOBID.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** medium

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: JOBID. 5. User determines domains (TBD): • creates own domains (Note: This may only apply to MM5 jobs. From earlier discussions: creating domain files for

### REQ-022: Domain determination options

**Description:** During job set up, the system shall allow the user to determine domains by creating own domains, choosing between pre-defined domains, or submitting own TERRAIN files.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** high

**Ambiguities:** ["Domain determination specifics are marked TBD; note indicates creating own domains may apply only to MM5 jobs due to WRF processing time."]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: JOBID. 5. User determines domains (TBD): • creates own domains (Note: This may only apply to MM5 jobs. From earlier discussions: creating domain files for
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: WRF takes a long time.) or • chooses between a number of pre-defined domains or • submits own TERRAIN files 6. User defines when a

### REQ-023: Run schedule and historical cycle prompting

**Description:** The system shall allow the user to define when a job is to be run and/or what cycle to run. If the specified cycle time is in the past, the system shall prompt the user to specify whether the job is a 'case study' or 're-run'.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** high

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: WRF takes a long time.) or • chooses between a number of pre-defined domains or • submits own TERRAIN files 6. User defines when a
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: job is to be run and/or what cycle to run. If the cycle time is in the past, then the user is prompted to specify
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: whether the job is a “case study” or “re-run”. 7. User supplies other job specific information, such as, cycle interval, forecast length and other applicable

### REQ-024: Job parameters specification

**Description:** The system shall allow the user to supply job-specific information including cycle interval, forecast length, and other applicable information.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** medium

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: whether the job is a “case study” or “re-run”. 7. User supplies other job specific information, such as, cycle interval, forecast length and other applicable
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: information. 8. User can specify whether to write restart files and the frequency of how often they are to be written (TBD: Is this a

### REQ-025: Restart file writing configuration

**Description:** The system shall allow the user to specify whether to write restart files and the frequency at which they are to be written.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** low

**Ambiguities:** ["Statement correctness and whether frequency applies only to WRF are marked TBD."]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: information. 8. User can specify whether to write restart files and the frequency of how often they are to be written (TBD: Is this a
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: correct statement and does frequency only apply to WRF?). 9. User can choose between predefined sigma-level configurations or supply own sigma- level configuration 10.User has

### REQ-026: Sigma-level configuration options

**Description:** The system shall allow the user to choose between predefined sigma-level configurations or supply their own sigma-level configuration.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** medium

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: correct statement and does frequency only apply to WRF?). 9. User can choose between predefined sigma-level configurations or supply own sigma- level configuration 10.User has

### REQ-027: Node count specification

**Description:** The system shall give the user the option to specify the number of nodes to use for a job.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** medium

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: correct statement and does frequency only apply to WRF?). 9. User can choose between predefined sigma-level configurations or supply own sigma- level configuration 10.User has
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: the option to specify the number of nodes to use. 11.User can choose to receive email notification upon start, end and termination of the job.

### REQ-028: Email notification configuration

**Description:** The system shall allow the user to choose to receive email notifications upon the start, end, and termination of a job.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** medium

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: the option to specify the number of nodes to use. 11.User can choose to receive email notification upon start, end and termination of the job.

### REQ-029: IC/BC data sources selection and off-line requirements

**Description:** The system shall allow the user to choose between standard IC/BC data sources (ETA, AVNFTP (GFS), GFS004) or custom data sources (providing host and full path). For off-line jobs, the user must specify data source location (MetVault or a directory) and time period. For re-runs using MetVault, MetVault shall return the data available and used in that cycle.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** high

**Ambiguities:** ["Standard IC/BC data source and standard pre-processors are marked TBD."]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: 12.User chooses between standard or custom IC/BC data sources: • standard: ETA, AVNFTP (GFS), GFS004 or • custom: provide data source (e.g., host:Full_Path_to_Dir) or •
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: For off-line jobs, the user must specify the data source, i.e., location (MetVault or a directory) and time period. Important note for re-runs, if the
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: input data is to obtain from the MetVault, then MetVault returns the data that was available and used in that cycle. • TBD: Determine standard
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: IC/BC data source and standard pre-processors. 11.Depending on the choice above, user can provide custom IC/BC pre-processor or choose the standard: • standard processing or
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: • etc. or • For off-line jobs, the user must specify the data source, i.e., location (MetVault or a directory) and time period. Important note
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: for re-runs, if the input data is to obtain from the MetVault, then MetVault returns the data that was available and used in that cycle.

### REQ-030: IC/BC pre-processor selection

**Description:** The system shall allow the user to choose standard pre-processing or provide a custom IC/BC pre-processing script.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** medium

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: IC/BC data source and standard pre-processors. 11.Depending on the choice above, user can provide custom IC/BC pre-processor or choose the standard: • standard processing or
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: • provide own pre-processing script

### REQ-031: User responsibility for custom job assets location

**Description:** When submitting a 'custom' GMOD job through the Job-Setup module, it shall be the user's responsibility to ensure that custom scripts, executables, and related assets reside on the cluster or clusters where the job will be running.

**Requirement Type:** functional

**Module:** Job-Setup

**Priority:** medium

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: Functional Requirements Specification for the Model Manager Page 5 MM's Job-Setup module will allow the user to substitute the default configuration, but it is the
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: user's responsibility to make sure that these scripts, executables, etc. reside on the cluster or clusters where the job will be running on. Submitting a

### REQ-032: Run additional IC/BC pre-processors option

**Description:** The system shall give the user the option to run additional pre-processors for IC/BC data (such as LDAS), supply a custom pre-processor (including providing a custom pre-processing script), or skip this option.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: • provide own pre-processing script
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Functional Requirements Specification for the Model Manager Page 6 12.User is given the option to run additional pre-processors for the IC/BC data, such as, LDAS
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: or supply own custom pre-processor or skip this option. 13.User chooses between standard and/or custom obs data sources and processing: • Standard: WMO, SAMS, MADIS,

### REQ-033: Observational data sources and processing selection

**Description:** The system shall allow the user to choose between standard and/or custom observational data sources and processing, including selecting standard sources (WMO, SAMS, MADIS, GTS, RAWS, okmeso, SatWinds, ACARS, etc.) and/or providing custom observational sources and custom observational processors.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: or supply own custom pre-processor or skip this option. 13.User chooses between standard and/or custom obs data sources and processing: • Standard: WMO, SAMS, MADIS,
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: GTS, RAWS, okmeso, SatWinds, ACARS, etc. and/or • provide custom obs source1 and custom obs processor1 • provide custom obs source2 and custom obs processor2

### REQ-034: MM5 executable selection

**Description:** When MM5 model is chosen, the system shall present compiled standard MM5-executables based on previously determined domain size and node count for the user to choose from, or allow the user to supply their own executable (e.g., its cluster location).

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Ambiguities:** ["Exact definition of 'standard MM5 executable' is TBD."]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: • TBD: Define all standard observational data sources and identify their processing scripts. 14.Depending on the choice of the model different options are given to
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: the user: • MM5: The domain size and number of nodes for this job was determined earlier. Based on both choices, the user is presented
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: with different MM5-executables to choose from. These executables have been compiled in advanced. The MM will be able to retrieve the compile info about the
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: executables, e.g., domain size, number of nodes, number of sigma levels, etc. These few executables are standard executables (TBD: determine what 'standard MM5 executable’ means).
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Or, the user can also supply own executable, e.g., its location on the cluster • WRF: User defines model options (TBD: determine possible model options)

### REQ-035: WRF model options definition

**Description:** When the WRF model is chosen, the system shall allow the user to define model options.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** medium

**Ambiguities:** ["Possible WRF model options are TBD."]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Or, the user can also supply own executable, e.g., its location on the cluster • WRF: User defines model options (TBD: determine possible model options)

### REQ-036: Final Analysis run option

**Description:** The system shall allow the user to choose whether or not to run Final Analysis, which may only apply to re-runs and case studies.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** medium

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: 15.User chooses whether or not to run Final Analysis. This may only apply to re-runs and case studies. 16.User chooses whether or not to run

### REQ-037: Preliminary Analysis run option

**Description:** The system shall allow the user to choose whether or not to run Preliminary Analysis, which may only apply to re-runs and case studies.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** medium

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: 15.User chooses whether or not to run Final Analysis. This may only apply to re-runs and case studies. 16.User chooses whether or not to run
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Prelim. Analysis. This may only apply to re-runs and case studies. 17.User chooses whether or not run additional processing on the model output. (TBD: What

### REQ-038: Model output additional processing option

**Description:** The system shall allow the user to choose whether or not to run additional processing on the model output.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** medium

**Ambiguities:** ["Exact options for additional processing (e.g., Bias Correction) are TBD."]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Prelim. Analysis. This may only apply to re-runs and case studies. 17.User chooses whether or not run additional processing on the model output. (TBD: What
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: exactly are the options for additional processing? Bias Correction?) 18.User can choose to save the model output in MetVault. If 'yes', user must specify what

### REQ-039: Save model output in MetVault option

**Description:** The system shall allow the user to choose to save the model output in MetVault, requiring the user to specify which output file is to be sent if 'yes' is selected.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: exactly are the options for additional processing? Bias Correction?) 18.User can choose to save the model output in MetVault. If 'yes', user must specify what
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: output file is to be sent to the MetVault. 19.User is given the option to save and submit the job now. Submitting now, would run
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: chooses whether or not run additional processing on the model output. (TBD: Is 10. applicable to ClimoFDDA jobs? 11.User can choose to save the model
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: output in MetVault. If 'yes', user must specify what output, e.g., member and/or ensemble output is to be send to the MetVault. 12.User is given

### REQ-040: Immediate job submission option without post-processing

**Description:** The system shall provide the user the option to save and submit the job immediately, which will execute IC/BC-data processing, observational processing, and the model, but no post-processing.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: output file is to be sent to the MetVault. 19.User is given the option to save and submit the job now. Submitting now, would run
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: IC/BC-data and obs processing and the model, no post-processing. 20.User chooses whether or not to run post-processing. If ‘yes', then s/he will go through the

### REQ-041: Post-processing run option

**Description:** The system shall allow the user to choose whether or not to run post-processing, proceeding to the section 3.4 action sequence if 'yes' is selected.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Ambiguities:** ["Level of post-processing customization needed for RAL vs ranges users is TBD."]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: IC/BC-data and obs processing and the model, no post-processing. 20.User chooses whether or not to run post-processing. If ‘yes', then s/he will go through the
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: action sequence in 3.4. (TBD: How customizable should post-processing be? In GCAT, e.g., the user can specify locations for pseudo-soundings, cross sections, pseudo-obs, etc. Do

### REQ-042: Save job configuration to file

**Description:** The system shall allow the user to save the job configuration to a file.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** medium

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: pre-configured post-processing options be sufficient?) 21.User can save the above job configuration. Job configurations can be saved to a file. 22.User submits the job. Use

### REQ-043: Submit job

**Description:** The system shall allow the user to submit the job.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: pre-configured post-processing options be sufficient?) 21.User can save the above job configuration. Job configurations can be saved to a file. 22.User submits the job. Use

### REQ-044: ClimoFDDA job initial option selection

**Description:** When a logged-on user selects 'Submit a new job' -&gt; 'Set up a new model job', the system shall present two options: 'Weather FDDA' and 'Climo' (with MM currently supporting 'ClimoFDDA').

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: Functional Requirements Specification for the Model Manager Page 7 The objective of this feature is to integrate the GCAT functionalities within the MM. Suppose the
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: user is logged on to the system and has made the following choices “Submit a new job” -&gt; “Set up a new model job”. S/he
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: is then presented with two more options: “ Weather FDDA” and “Climo”. Primary actor: Meteorologist, software engineer Goal: Set up and run a ClimoFDDA job.
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: At this point, the MM only supports “ClimoFDDA”. Action Sequence: 1. Chooses to “Set up a Climo Job”. 2. User defines a JOBID. 3. User

### REQ-045: ClimoFDDA job setup parameters

**Description:** In setting up a ClimoFDDA job, the system shall allow the user to define a JOBID, supply other job parameters, determine domain location, and specify locations for pseudo-obs and custom cross sections.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Ambiguities:** ["Whether pseudo-obs and custom cross section locations are only used during post-processing is TBD."]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: At this point, the MM only supports “ClimoFDDA”. Action Sequence: 1. Chooses to “Set up a Climo Job”. 2. User defines a JOBID. 3. User
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: supplies other job parameters. For details, see GCAT tool 4. User determines the domain location. 5. User can specify locations for pseudo-obs and custom cross
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: sections. (TBD: Is this configuration information that is only used during post-processing?) 6. User picks a pre-configured MM5 setup 7. User sets the time line

### REQ-046: ClimoFDDA MM5 setup and timeline configuration

**Description:** During ClimoFDDA job setup, the system shall allow the user to pick a pre-configured MM5 setup and set the job timeline including start time, end time, and target years.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: sections. (TBD: Is this configuration information that is only used during post-processing?) 6. User picks a pre-configured MM5 setup 7. User sets the time line
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: for the job: start time, end time and what years 8. User sets the ensemble options: • hourly (TBD: Are there other options? Daily?) •

### REQ-047: ClimoFDDA ensemble options configuration

**Description:** During ClimoFDDA job setup, the system shall allow the user to set ensemble options including hourly frequency, statistical measures (min, max, mean, standard deviation, etc.), diurnal cycle, and typical moment.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Ambiguities:** ["Whether additional ensemble frequency options (e.g., daily) exist beyond hourly is TBD."]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: for the job: start time, end time and what years 8. User sets the ensemble options: • hourly (TBD: Are there other options? Daily?) •
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: min, max, mean, standard deviation,.... • diurnal cycle • typical moment 9. User can request the number of nodes this job should run on. 10.User

### REQ-048: ClimoFDDA cluster nodes request

**Description:** In a ClimoFDDA job setup, the system shall allow the user to request the number of nodes the job should run on.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** medium

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: min, max, mean, standard deviation,.... • diurnal cycle • typical moment 9. User can request the number of nodes this job should run on. 10.User

### REQ-049: ClimoFDDA model output additional processing option

**Description:** In a ClimoFDDA job setup, the system shall allow the user to choose whether or not to run additional processing on the model output.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** medium

**Ambiguities:** ["Applicability of model output additional processing to ClimoFDDA jobs is TBD."]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: min, max, mean, standard deviation,.... • diurnal cycle • typical moment 9. User can request the number of nodes this job should run on. 10.User
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: chooses whether or not run additional processing on the model output. (TBD: Is 10. applicable to ClimoFDDA jobs? 11.User can choose to save the model

### REQ-050: ClimoFDDA immediate save and submit option

**Description:** In a ClimoFDDA job setup, the system shall give the user the option to save and submit the job immediately, which will run member models, the ensemble, and possible model output processing, but no post-processing.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: output in MetVault. If 'yes', user must specify what output, e.g., member and/or ensemble output is to be send to the MetVault. 12.User is given
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: the option to save and submit the job now. Submitting now, would run the member models, the ensemble, and possible model output processing, no post-
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: processing. 13.User chooses whether or not to run post-processing on the ensemble output. If “yes', then s/he will be presented with the following options: •

### REQ-051: ClimoFDDA post-processing on ensemble output and destination specification

**Description:** In a ClimoFDDA job setup, the system shall allow the user to choose whether or not to run post-processing on ensemble output. If 'yes', the system shall present product options (Plots [NCL or RIP], NAPS, MDV, Sites, MEDOC [1–4], Raster, PRF, Wind Roses, etc.) and prompt the user for a destination host and location for each output product file.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: processing. 13.User chooses whether or not to run post-processing on the ensemble output. If “yes', then s/he will be presented with the following options: •
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: Plots (NCL or RIP) • NAPS • MDV • Sites • MEDOC (1 – 4) (?) • Raster • PRF • Wind Roses • ...
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: For each output product, the user is prompted to supply a destination host and location, where the output files should be copied.

### REQ-052: Select Set up a Climo Job option

**Description:** When setting up a ClimoFDDA job, the system shall allow the user to select the option to 'Set up a Climo Job'.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** medium

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: At this point, the MM only supports “ClimoFDDA”. Action Sequence: 1. Chooses to “Set up a Climo Job”. 2. User defines a JOBID. 3. User

### REQ-053: Specify post-processing for members' output

**Description:** The user can specify whether the members' output should be post-processed, including which year-output to post-process, what post-processor(s) to use, and where the output files should be copied.

**Requirement Type:** functional

**Module:** Model Manager / Job Setup

**Priority:** medium

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: Functional Requirements Specification for the Model Manager Page 8 14.The user can also specify whether the members' output should be post-processed. S/he can specify which
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: year-output to post-process and what post-processor(s) to use and where the output files should be copied. 15. The user can specify whether another process (coupled

### REQ-054: Run coupled application on post-process output

**Description:** The user can specify whether another process (coupled app) should be run on the post-process output products.

**Requirement Type:** functional

**Module:** Model Manager / Job Setup

**Priority:** medium

**Ambiguities:** ["Needs further clarification."]

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: year-output to post-process and what post-processor(s) to use and where the output files should be copied. 15. The user can specify whether another process (coupled
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: app) should be run on the post-process output products. This needs further clarification. 16.User can save the above job configuration. Job configurations can be saved

### REQ-055: Save job configuration to file

**Description:** The user can save the job configuration to a file.

**Requirement Type:** functional

**Module:** Model Manager / Job Setup

**Priority:** medium

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: app) should be run on the post-process output products. This needs further clarification. 16.User can save the above job configuration. Job configurations can be saved
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: to a file. 17.User submits the job. Use Case “CAM”: Setting up a CAM job TBD 3.2 Set up and submit a “post-processing” job The

### REQ-056: Submit post-processing job configuration

**Description:** The user can submit the configured job.

**Requirement Type:** functional

**Module:** Model Manager / Job Setup

**Priority:** medium

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: to a file. 17.User submits the job. Use Case “CAM”: Setting up a CAM job TBD 3.2 Set up and submit a “post-processing” job The

### REQ-057: Select post-processing job setup

**Description:** The system shall allow the user to select 'Set up a new 'post-processing' job'.

**Requirement Type:** functional

**Module:** Model Manager / Job Setup

**Priority:** medium

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: new job”. Primary actor: Meteorologist, software engineer Goal: Run post-processing on model output Action Sequence: 1. User selects “Set up a new 'post-processing' job” .

### REQ-058: Prompt for model output file details

**Description:** The user is prompted to supply location and name of the model output file: supplying JOBID &amp; cycle time if the file will be produced by a running/scheduled FDDA-job, or supplying its location if the file already exists.

**Requirement Type:** functional

**Module:** Model Manager / Job Setup

**Priority:** medium

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: 2. User is prompted to supply location and name of the model output file: • If the model output file will be produced by a
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: running or scheduled FDDA-job, then the user supplies JOBID &amp; cycle time • If the model output file already exists, then the user supplies its
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: location. 3. User chooses the type of post-processing: • Plots (NCL or RIP) • NAPS • MDV • Sites • MEDOC (1 – 4) (?)

### REQ-059: Choose post-processing type

**Description:** The user chooses the type of post-processing from options including Plots (NCL or RIP), NAPS, MDV, Sites, MEDOC (1 – 4), Stereo, or Verification.

**Requirement Type:** functional

**Module:** Model Manager / Job Setup

**Priority:** medium

**Ambiguities:** ["Uncertainty flagged in source regarding MEDOC (1 – 4) (?)"]

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: location. 3. User chooses the type of post-processing: • Plots (NCL or RIP) • NAPS • MDV • Sites • MEDOC (1 – 4) (?)
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: • Stereo • Verification 4. For each of the options chosen in 3., the user can supply a custom configuration file (if this is applicable)

### REQ-060: Supply configuration file for post-processing options

**Description:** For each post-processing option chosen, the user can supply a custom configuration file (if applicable) or use the default configuration file.

**Requirement Type:** functional

**Module:** Model Manager / Job Setup

**Priority:** medium

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: • Stereo • Verification 4. For each of the options chosen in 3., the user can supply a custom configuration file (if this is applicable)
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: or use the default configuration file. 5. User must supply destination location for the output products. 6. User can specify the number of nodes this

### REQ-061: Supply destination location for post-processing output products

**Description:** The user must supply a destination location for the output products.

**Requirement Type:** functional

**Module:** Model Manager / Job Setup

**Priority:** high

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: or use the default configuration file. 5. User must supply destination location for the output products. 6. User can specify the number of nodes this

### REQ-062: Specify number of nodes for post-processing job

**Description:** The user can specify the number of nodes this post-processing job should run on.

**Requirement Type:** functional

**Module:** Model Manager / Job Setup

**Priority:** low

**Ambiguities:** ["TBD: Is this a correct requirement?"]

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: or use the default configuration file. 5. User must supply destination location for the output products. 6. User can specify the number of nodes this
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: job should run on (TBD: Is this a correct requirement?) 7. User can save this job's setting. Job configurations can be saved to a file.

### REQ-063: Save post-processing job settings

**Description:** The user can save the post-processing job's setting to a file.

**Requirement Type:** functional

**Module:** Model Manager / Job Setup

**Priority:** medium

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: job should run on (TBD: Is this a correct requirement?) 7. User can save this job's setting. Job configurations can be saved to a file.

### REQ-064: Submit post-processing job

**Description:** The user submits the post-processing job.

**Requirement Type:** functional

**Module:** Model Manager / Job Setup

**Priority:** medium

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: Functional Requirements Specification for the Model Manager Page 9 8. User submits job. 3.3 Submit a 'By-hand' job The objective of this feature is to

### REQ-065: Select 'Submit a By Hand Job'

**Description:** The user selects 'Submit a 'By Hand' Job'.

**Requirement Type:** functional

**Module:** Model Manager / By-hand Job

**Priority:** medium

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: 1. User selects “Submit a 'By Hand' Job” 2. User supplies: Mandatory: • job id (GMUAE, GWDPG,...) • location of the script (host:/full_path_to_script) • time

### REQ-066: Supply mandatory information for 'By-hand' job

**Description:** For a 'By-hand' job, the user supplies mandatory information including job id (e.g., GMUAE, GWDPG), location of the script (host:/full_path_to_script), time when to run the script, estimated time of how long the script will run, name(s) of executable(s), max. runtime for the executable(s), number of nodes, and location of output products (such as: host:/dir_path).

**Requirement Type:** functional

**Module:** Model Manager / By-hand Job

**Priority:** high

**Ambiguities:** ["Source marks 'number of nodes (??)' with explicit question marks."]

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: 1. User selects “Submit a 'By Hand' Job” 2. User supplies: Mandatory: • job id (GMUAE, GWDPG,...) • location of the script (host:/full_path_to_script) • time
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: when to run the script • estimated time of how long the script will run • name(s) of executable(s) • max. runtime for the executable(s)
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: • number of nodes (??) • location of output products (such as: host:/dir_path) Optional: • frequency of how often the script should run • job

### REQ-067: Supply optional information for 'By-hand' job

**Description:** For a 'By-hand' job, the user can supply optional information including frequency of how often the script should run, job type, and any additional information.

**Requirement Type:** functional

**Module:** Model Manager / By-hand Job

**Priority:** low

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: • number of nodes (??) • location of output products (such as: host:/dir_path) Optional: • frequency of how often the script should run • job
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: type • any additional information 3. User can save the job's settings. Job configurations can be saved to a file. 4. User submits job. 5.

### REQ-068: Save 'By-hand' job settings

**Description:** The user can save the 'By-hand' job's settings to a file.

**Requirement Type:** functional

**Module:** Model Manager / By-hand Job

**Priority:** medium

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: type • any additional information 3. User can save the job's settings. Job configurations can be saved to a file. 4. User submits job. 5.

### REQ-069: Submit 'By-hand' job

**Description:** The user submits the 'By-hand' job.

**Requirement Type:** functional

**Module:** Model Manager / By-hand Job

**Priority:** medium

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: type • any additional information 3. User can save the job's settings. Job configurations can be saved to a file. 4. User submits job. 5.

### REQ-070: View 'By-hand' job in job queue

**Description:** The user can view his/her submitted 'By-hand' job in the job queue.

**Requirement Type:** functional

**Module:** Model Manager / By-hand Job

**Priority:** medium

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: type • any additional information 3. User can save the job's settings. Job configurations can be saved to a file. 4. User submits job. 5.
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: User can view his/her job in the job queue (see 3.1.). 6. User can receive an email notification when job is started, finished or killed.

### REQ-071: Receive email notification for 'By-hand' job status

**Description:** The user can receive an email notification when the job is started, finished, or killed.

**Requirement Type:** functional

**Module:** Model Manager / By-hand Job

**Priority:** medium

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: User can view his/her job in the job queue (see 3.1.). 6. User can receive an email notification when job is started, finished or killed.

### REQ-072: Notify Model Manager when custom job completes

**Description:** A 'custom' job must notify the Model Manager when done.

**Requirement Type:** functional

**Module:** Model Manager / By-hand Job

**Priority:** high

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: (SRS Note: 'custom' job will need to notify the MM when done.) 3.4 Load a job configuration from a file and submit the job The

### REQ-073: Select 'Submit a job configuration file'

**Description:** The user selects 'Submit a job configuration file'.

**Requirement Type:** functional

**Module:** Model Manager / Load Job Configuration

**Priority:** medium

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: to the system and has made the following choice, “Submit a new job”. Primary actor: Meteorologist, software engineer Action Sequence: 1. User selects ”Submit a
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: ”Submit a job configuration file”.

### REQ-074: Supply file name to load job configuration

**Description:** The user supplies a file name to load a job configuration into MM.

**Requirement Type:** functional

**Module:** Model Manager / Load Job Configuration

**Priority:** medium

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: Functional Requirements Specification for the Model Manager Page 10 2. User supplies file name to load. 3. User can make changes to the configuration. 4.

### REQ-075: Modify loaded job configuration

**Description:** The user can make changes to the loaded job configuration.

**Requirement Type:** functional

**Module:** Model Manager / Load Job Configuration

**Priority:** medium

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: Functional Requirements Specification for the Model Manager Page 10 2. User supplies file name to load. 3. User can make changes to the configuration. 4.

### REQ-076: Save modified job configuration

**Description:** The user can save the changed job configuration.

**Requirement Type:** functional

**Module:** Model Manager / Load Job Configuration

**Priority:** medium

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: Functional Requirements Specification for the Model Manager Page 10 2. User supplies file name to load. 3. User can make changes to the configuration. 4.
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: User can save the changed configuration. 5. User submits the job. 3.5 Retrieve and run a previously saved job configuration The objective of this feature
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: job configuration. 4. User changes the job configuration. 5. User can save the changed job configuration. 6. User submits job. 3.6 View scheduled, running and

### REQ-077: Submit job from loaded configuration

**Description:** The user submits the job after loading/modifying the job configuration.

**Requirement Type:** functional

**Module:** Model Manager / Load Job Configuration

**Priority:** medium

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: User can save the changed configuration. 5. User submits the job. 3.5 Retrieve and run a previously saved job configuration The objective of this feature

### REQ-078: Log on with user id and password for saved configurations

**Description:** The user logs on with user id/password to retrieve saved job configurations.

**Requirement Type:** functional

**Module:** Model Manager / Retrieve Job Configuration

**Priority:** medium

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: actor: Meteorologist, software engineer Goal: Run a previously configured job. Action Sequence: 1. User logs on with user id/password. 2. User chooses to look at

### REQ-079: View previously saved job configurations table

**Description:** The user chooses to view his/her previously saved job configurations, presented as a table that may include attributes such as Job id, Job type, Cycle time that was run last (if applicable), and time this job was run last.

**Requirement Type:** functional

**Module:** Model Manager / Retrieve Job Configuration

**Priority:** medium

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: actor: Meteorologist, software engineer Goal: Run a previously configured job. Action Sequence: 1. User logs on with user id/password. 2. User chooses to look at
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: his/her previously saved job configurations. A table of saved jobs may include the following attributes: • Job id • Job type • Cycle time that
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: was run last (if applicable) • time this job was run last • ... 3. User selects a job. User can change or delete this

### REQ-080: Select, change, or delete a saved job configuration

**Description:** The user selects a job from saved configurations and can change or delete this job configuration.

**Requirement Type:** functional

**Module:** Model Manager / Retrieve Job Configuration

**Priority:** medium

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: was run last (if applicable) • time this job was run last • ... 3. User selects a job. User can change or delete this
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: job configuration. 4. User changes the job configuration. 5. User can save the changed job configuration. 6. User submits job. 3.6 View scheduled, running and

### REQ-081: Submit job from retrieved configuration

**Description:** The user submits the job after retrieving or changing a saved job configuration.

**Requirement Type:** functional

**Module:** Model Manager / Retrieve Job Configuration

**Priority:** medium

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: job configuration. 4. User changes the job configuration. 5. User can save the changed job configuration. 6. User submits job. 3.6 View scheduled, running and

### REQ-082: Log on to view scheduled, running, and old jobs

**Description:** The user logs on with user id/password to monitor running jobs, view the job queue, or view past jobs.

**Requirement Type:** functional

**Module:** Model Manager / View Jobs

**Priority:** medium

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: past. Primary actor: Meteorologist, software engineer Goal: Monitor a running job and view scheduled and old jobs Action Sequence: 1. User logs on with user
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: id/password. 2. User chooses to look at all running jobs, all scheduled jobs (the job queue), past jobs or all jobs (running, scheduled, old). User

### REQ-083: Select job viewing option

**Description:** The user chooses to look at all running jobs, all scheduled jobs (the job queue), past jobs, or all jobs (running, scheduled, old) by selecting one of the four options.

**Requirement Type:** functional

**Module:** Model Manager / View Jobs

**Priority:** medium

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: id/password. 2. User chooses to look at all running jobs, all scheduled jobs (the job queue), past jobs or all jobs (running, scheduled, old). User
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: selects one of the four options. 3. User is presented with a job table. Depending on the user's choice in 2, the job table may

### REQ-084: Display job table with user id attribute

**Description:** The user is presented with a job table based on the selected viewing option, which may present attributes including user id – the 'owner' of the job.

**Requirement Type:** functional

**Module:** Model Manager / View Jobs

**Priority:** medium

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: selects one of the four options. 3. User is presented with a job table. Depending on the user's choice in 2, the job table may
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: present the following attributes to the user: • user id – the 'owner' of the job

### REQ-085: Identify clusters and register custom job for By-hand submission

**Description:** In order to submit a custom job to the MM, the user must first identify the cluster(s) where his/her job should run on, log on to this machine, perform operations necessary for setting up the job, and register the job with the MM.

**Requirement Type:** functional

**Module:** By-hand Job

**Priority:** high

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: accommodate the current GMOD-framework. It will also give the user the ability to run customized jobs. In order to submit a custom job to the
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: MM, the user must first identify the cluster(s), where his/her job should run on. Then, log on to this machine, perform operations that are necessary
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: for setting up the job and then register the job with the MM (see Action Sequence below). It is important to note that since a

### REQ-086: Display Job Attributes

**Description:** The Model Manager must present the following attributes for a job to the user: Job id, Job type (such as GMOD, climoFDDA, FDDA-re-run, case study, custom, etc.), Job priority, start time, remaining time (estimated) or time it took to run the job, cycle (if applicable), stage (Pre-processing, F-analysis, Prelim. Analysis, etc.), status (SCHEDULED, RUNNING, status in % - if applicable, DONE), cluster and nodes (for a running job), and number of processors.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Ambiguities:** ["Job priority prioritization mechanism is TBD", "Exact list of 'and others' attributes is not specified"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: Functional Requirements Specification for the Model Manager Page 11 • Job id • Job type – such as: GMOD, climoFDDA, FDDA-re-run, case study, custom,.... •
- PDF p. 13, , `p0013-c001-139ddec67a27`: Job priority (TBD: How should jobs be prioritized?) • start time • remaining time (estimated) or time it took to run the job • cycle
- PDF p. 13, , `p0013-c001-139ddec67a27`: (if applicable) • stage (Pre-processing, F-analysis, Prelim. Analysis,...) • status ( SCHEDULED, RUNNING, status in % - if applicable, DONE) • cluster and nodes (for
- PDF p. 13, , `p0013-c001-139ddec67a27`: a running job) • number of processors • and others 4. User can select a job and receive more detailed information (TBD: What exactly are

### REQ-087: Select Job for Detailed Information

**Description:** The user can select a job to receive more detailed information.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** medium

**Ambiguities:** ["What exactly constitutes the detailed information is TBD"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: a running job) • number of processors • and others 4. User can select a job and receive more detailed information (TBD: What exactly are
- PDF p. 13, , `p0013-c001-139ddec67a27`: the details?) 5. User can look at a jobs log files. 6. User can delete his/her jobs from the job queue. A “super user” can

### REQ-088: View Job Log Files

**Description:** The user can look at a job's log files.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** medium

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: the details?) 5. User can look at a jobs log files. 6. User can delete his/her jobs from the job queue. A “super user” can

### REQ-089: Delete Job from Job Queue

**Description:** A user can delete his/her own jobs from the job queue. A 'super user' can delete any job from the job queue.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: the details?) 5. User can look at a jobs log files. 6. User can delete his/her jobs from the job queue. A “super user” can
- PDF p. 13, , `p0013-c001-139ddec67a27`: delete any job from the job queue. 7. User can stop his/her running job. A “super user” can stop any running job. 8. User can

### REQ-090: Stop Running Job

**Description:** A user can stop his/her running job. A 'super user' can stop any running job.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: delete any job from the job queue. 7. User can stop his/her running job. A “super user” can stop any running job. 8. User can

### REQ-091: Re-start Job

**Description:** A user can re-start his/her job. A 'super user' can re-start any job.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: delete any job from the job queue. 7. User can stop his/her running job. A “super user” can stop any running job. 8. User can
- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### REQ-092: Resume Stopped Job

**Description:** A user can resume his/her stopped job. A 'super user' can resume any stopped job.

**Requirement Type:** functional

**Module:** Model Manager

**Priority:** high

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

## Scenarios (96)

### SCN-001: Configure, Schedule, Run, Monitor, and Lifecycle Management of Model Jobs via MM

**Scenario Id:** SCN-001

**Objective:** Verify that Model Manager allows users to configure, schedule, run, monitor, stop, and restart/resume model jobs.

**Scenario Type:** positive

**Preconditions:** ["Model Manager environment is running and accessible."]

**Requirement Ids:** ["REQ-001"]

**Source evidence**

- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: NSAP project sponsors and management. 1.4 Project Scope The Model Manager is a software tool that will allow the user to configure, schedule, run, monitor,

### SCN-002: Back End System Extension and Automated Node Job Execution

**Scenario Id:** SCN-002

**Objective:** Verify that Model Manager extends the model back end system to automate job setup, running, monitoring, and automated node management.

**Scenario Type:** positive

**Preconditions:** ["Model back end system is integrated with the Model Manager automated node management module."]

**Requirement Ids:** ["REQ-002"]

**Source evidence**

- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: and stop (and re-start /resume) model jobs. The primary goal of this project is to extend the current model back end system and to automate
- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: the setup, running and monitoring of model jobs. This will include a more automated node management system. 1.5 References [1] “4DWX on the Move (4DWX

### SCN-003: Execute MM as Stand-alone Application

**Scenario Id:** SCN-003

**Objective:** Verify that Model Manager operates successfully as a stand-alone tool with no knowledge of or dependence on MetVault.

**Scenario Type:** positive

**Preconditions:** ["Model Manager is configured in stand-alone execution mode with MetVault integrations disabled/absent."]

**Requirement Ids:** ["REQ-003"]

**Source evidence**

- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: to the current model back end. The MM is a stand- alone software tool, which will also be part of the 4DWX OTM system (see
- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: stand-alone application with no knowledge about a MetVault. The MM will be accessible from a web-based GUI and a command line tool. 2.2 Product Features

### SCN-004: Execute MM in Conjunction with MetVault and 4DWX OTM System

**Scenario Id:** SCN-004

**Objective:** Verify that Model Manager operates in conjunction with MetVault as part of the 4DWX OTM system.

**Scenario Type:** positive

**Preconditions:** ["MetVault service and 4DWX OTM system components are active and accessible."]

**Requirement Ids:** ["REQ-003"]

**Source evidence**

- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: to the current model back end. The MM is a stand- alone software tool, which will also be part of the 4DWX OTM system (see
- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: Functional Requirements Specification for the Model Manager Page 3 The MM can run in conjunction with the MetVault, and it can also run as a

### SCN-005: User Access via Web-Based GUI

**Scenario Id:** SCN-005

**Objective:** Verify that users can access and interact with Model Manager using a web-based GUI.

**Scenario Type:** positive

**Preconditions:** ["Model Manager web service is hosted and network accessible."]

**Requirement Ids:** ["REQ-004"]

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: stand-alone application with no knowledge about a MetVault. The MM will be accessible from a web-based GUI and a command line tool. 2.2 Product Features
- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: [1]). Command Line ToolModel ManagerMetVault Web-based GUI

### SCN-006: User Access via Command Line Tool

**Scenario Id:** SCN-006

**Objective:** Verify that users can access and interact with Model Manager via the command line interface.

**Scenario Type:** positive

**Preconditions:** ["Model Manager command line tool binary is installed and configured in system path."]

**Requirement Ids:** ["REQ-004"]

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: stand-alone application with no knowledge about a MetVault. The MM will be accessible from a web-based GUI and a command line tool. 2.2 Product Features
- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: [1]). Command Line ToolModel ManagerMetVault Web-based GUI

### SCN-007: Submit a By-Hand Job

**Scenario Id:** SCN-007

**Objective:** Verify that the system allows users to successfully submit a 'by-hand' job.

**Scenario Type:** positive

**Preconditions:** ["User is logged in to Model Manager."]

**Requirement Ids:** ["REQ-005"]

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: view the status of operational model runs, stop and restart existing jobs or set up and start a 'standard' model job. Submit a 'by-hand' job

### SCN-008: Submit a Job Defined by a Configuration File

**Scenario Id:** SCN-008

**Objective:** Verify that the system allows users to submit a job defined by a configuration file.

**Scenario Type:** positive

**Preconditions:** ["A valid job configuration file is prepared on the local/accessible system."]

**Requirement Ids:** ["REQ-005"]

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: view the status of operational model runs, stop and restart existing jobs or set up and start a 'standard' model job. Submit a 'by-hand' job

### SCN-009: Retrieve a Previously Saved Job Configuration

**Scenario Id:** SCN-009

**Objective:** Verify that users can retrieve a previously saved job configuration from the system.

**Scenario Type:** positive

**Preconditions:** ["At least one saved job configuration exists in the system database/storage."]

**Requirement Ids:** ["REQ-006"]

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a

### SCN-010: Stop an Active Running Job

**Scenario Id:** SCN-010

**Objective:** Verify that the system allows users to stop an actively running job.

**Scenario Type:** state_transition

**Preconditions:** ["A model job is currently in 'RUNNING' state."]

**Requirement Ids:** ["REQ-007"]

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a

### SCN-011: Start a New Job

**Scenario Id:** SCN-011

**Objective:** Verify that the system allows users to start a new job.

**Scenario Type:** positive

**Preconditions:** ["Job configuration is complete and ready to run."]

**Requirement Ids:** ["REQ-008"]

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a

### SCN-012: Restart / Resume an Existing Job

**Scenario Id:** SCN-012

**Objective:** Verify that the system allows users to restart or resume an existing stopped/interrupted job.

**Scenario Type:** state_transition

**Preconditions:** ["An existing job is in a stopped or partially completed state."]

**Requirement Ids:** ["REQ-008"]

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a

### SCN-013: Change and save a job configuration

**Scenario Id:** SCN-013

**Objective:** Verify that the system allows a user to change and save a job configuration.

**Scenario Type:** positive

**Preconditions:** ["User is logged in.", "At least one saved job configuration exists."]

**Requirement Ids:** ["REQ-009"]

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a
- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: job configuration (optional) Set up a new model or “post- processing” job Monitor running jobs

### SCN-014: Set up a new model or post-processing job

**Scenario Id:** SCN-014

**Objective:** Verify that the system provides functionality to set up both a new model job and a post-processing job.

**Scenario Type:** positive

**Preconditions:** ["User is logged in to the system."]

**Requirement Ids:** ["REQ-010"]

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: job configuration (optional) Set up a new model or “post- processing” job Monitor running jobs

### SCN-015: Monitor running jobs in the system

**Scenario Id:** SCN-015

**Objective:** Verify that the system allows the user to monitor jobs currently running.

**Scenario Type:** positive

**Preconditions:** ["User is logged in.", "One or more jobs are submitted or running on the system."]

**Requirement Ids:** ["REQ-011"]

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: job configuration (optional) Set up a new model or “post- processing” job Monitor running jobs

### SCN-016: Model Manager cluster decision making and node management for submitted job

**Scenario Id:** SCN-016

**Objective:** Verify that Model Manager manages node allocation, utilization, and cluster decision making when a job is submitted without explicit cluster targeting.

**Scenario Type:** positive

**Preconditions:** ["Model Manager is controlling one or more clusters."]

**Requirement Ids:** ["REQ-012"]

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: MM will manage jobs on one or more clusters. Node allocation, management and utilization will be provided by the MM (SRS note: The MM provides
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: many and which clusters a MM is managing. S/he will submit a job to the MM and the MM will make the decision on what

### SCN-017: User explicitly specifies target cluster during customized job setup

**Scenario Id:** SCN-017

**Objective:** Verify that the user is provided with an option to specify a specific target cluster during submission of a customized job.

**Scenario Type:** positive

**Preconditions:** ["User is setting up a customized job in the Job-Setup module.", "Multiple target clusters are registered with the system."]

**Requirement Ids:** ["REQ-013"]

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: the user will need to have the option to specify what cluster his/her job should run on. Managing more than one cluster, will also allow
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: may choose a cluster where the job should run on. 3. User decides what model should be used: MM5 or WRF. 4. User defines a

### SCN-018: Execute RTFDDA and climoFDDA ensembles across several clusters

**Scenario Id:** SCN-018

**Objective:** Verify that the system allows RTFDDA and climoFDDA ensemble jobs to run across several clusters.

**Scenario Type:** positive

**Preconditions:** ["Model Manager manages multiple available clusters."]

**Requirement Ids:** ["REQ-014"]

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: the user will need to have the option to specify what cluster his/her job should run on. Managing more than one cluster, will also allow
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: RTFDDA and climoFDDA ensembles to run across several clusters. Once a user is logged in into the system, s/he will be presented with the features

### SCN-019: Main menu feature options presented upon user login

**Scenario Id:** SCN-019

**Objective:** Verify that upon logging in, the main menu presents options to submit a new job, retrieve saved job configurations, and view the job queue/monitor running jobs.

**Scenario Type:** positive

**Preconditions:** ["User possesses valid login credentials."]

**Requirement Ids:** ["REQ-015"]

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: RTFDDA and climoFDDA ensembles to run across several clusters. Once a user is logged in into the system, s/he will be presented with the features
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: in 2.2: • Submit a new job • Retrieve saved job configurations • View the job queue/monitor running jobs A new job can be submitted

### SCN-020: Submit new job via Job-Setup module, by-hand job, job configuration file, and re-submitting changed configuration

**Scenario Id:** SCN-020

**Objective:** Verify all four methods for submitting a new job to the Model Manager.

**Scenario Type:** positive

**Preconditions:** ["User is logged into the system.", "A previously saved job configuration exists for method 4.", "Submission options terminology is acknowledged as subject to change."]

**Requirement Ids:** ["REQ-016"]

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: in 2.2: • Submit a new job • Retrieve saved job configurations • View the job queue/monitor running jobs A new job can be submitted
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: to the MM four different ways: • The user can set up a new model or 'post-processing' job through the Job-Setup module and submit it
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: (3.1 and 3.2). • The user can submit a 'by-hand' job (3.3). • The user can submit a job by supplying a job configuration file
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: to the MM (3.4). • The user can retrieve a job configuration that was previously saved with the MM, change it and re-submit that job
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: (3.5). If the user chooses to submit a new job, s/he will be given the following options to choose from: • “Setup a new model

### SCN-021: Verify new model job type options during job setup

**Scenario Id:** SCN-021

**Objective:** Ensure the system presents 'Weather FDDA' and 'Climo' options when a user chooses to set up a new model job.

**Scenario Type:** positive

**Preconditions:** ["User is logged on to the Model Manager system."]

**Requirement Ids:** ["REQ-017"]

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: MM's Job-Setup module. Suppose the user is logged on to the system and has made the following choices “Submit a new job” -&gt; “Set up
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: a new model job”. S/he is then presented with two more options: “ Weather FDDA” and “Climo”. Use Case “WeatherFDDA”: Setting up a real time

### SCN-022: Submit RTFDDA ensemble job as a 'by hand' job

**Scenario Id:** SCN-022

**Objective:** Verify that the MM accepts an RTFDDA ensemble job submitted via 'by hand' method.

**Scenario Type:** positive

**Preconditions:** ["User is logged on and in job submission interface."]

**Requirement Ids:** ["REQ-018"]

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: case describes the set up of GMOD jobs, re-runs and case studies. At this point, RTFDDA ensemble jobs will be submitted to the MM as

### SCN-023: Submit RTFDDA ensemble job through a job configuration file

**Scenario Id:** SCN-023

**Objective:** Verify that the MM accepts an RTFDDA ensemble job submitted using a job configuration file.

**Scenario Type:** positive

**Preconditions:** ["User has a valid RTFDDA ensemble job configuration file."]

**Requirement Ids:** ["REQ-018"]

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: case describes the set up of GMOD jobs, re-runs and case studies. At this point, RTFDDA ensemble jobs will be submitted to the MM as
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: 'by hand' jobs or through a job configuration file. The MM will provide a default GMOD job configuration, which can be changed by the user

### SCN-024: Verify default GMOD job configuration provision and modification

**Scenario Id:** SCN-024

**Objective:** Confirm MM provides a default GMOD job configuration (with TBD defaults) and allows user modification.

**Scenario Type:** positive

**Preconditions:** ["User is in the Job-Setup module."]

**Requirement Ids:** ["REQ-019"]

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: 'by hand' jobs or through a job configuration file. The MM will provide a default GMOD job configuration, which can be changed by the user
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: (TBD: Define the defaults for a GMOD job). It is important to note that the model manager will accept and run “custom” GMOD jobs. These

### SCN-025: Set up, accept, run, and save custom GMOD job configuration with custom substitutions

**Scenario Id:** SCN-025

**Objective:** Verify MM accepts and runs custom GMOD jobs with substituted defaults (user input data, pre-processors, or customized MM5 executables) and allows saving the configuration.

**Scenario Type:** positive

**Preconditions:** ["User has created/provided necessary custom scripts, executables, or input data on the target cluster."]

**Requirement Ids:** ["REQ-019"]

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: (TBD: Define the defaults for a GMOD job). It is important to note that the model manager will accept and run “custom” GMOD jobs. These
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: are jobs that are also set up through the Setup-module, but do not use the default GMOD configuration For a “custom” GMOD job, e.g., the
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: user may choose to supply his/her own input data, own pre-processors or a customized version of a MM5 executable.
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: Functional Requirements Specification for the Model Manager Page 5 MM's Job-Setup module will allow the user to substitute the default configuration, but it is the
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: “custom” GMOD job thought the Job-Setup module will allow the user to save the job's configuration with the MM. Primary actor: Meteorologist, software engineer Goal:

### SCN-026: Model selection for Weather FDDA job (MM5 vs WRF)

**Scenario Id:** SCN-026

**Objective:** Verify user can select MM5 or WRF model during Weather FDDA job set up.

**Scenario Type:** positive

**Preconditions:** ["User has selected Weather FDDA job setup option."]

**Requirement Ids:** ["REQ-020"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: Set up and run a real time and off-line GMOD job Action Sequence: 1. User chooses to “Set up a Weather FDDA Job”. 2. User
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: may choose a cluster where the job should run on. 3. User decides what model should be used: MM5 or WRF. 4. User defines a

### SCN-027: Define JOBID during Weather FDDA job set up

**Scenario Id:** SCN-027

**Objective:** Verify system requires/allows the user to define a JOBID during Weather FDDA job set up.

**Scenario Type:** positive

**Preconditions:** ["User is in Weather FDDA job setup sequence."]

**Requirement Ids:** ["REQ-021"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: JOBID. 5. User determines domains (TBD): • creates own domains (Note: This may only apply to MM5 jobs. From earlier discussions: creating domain files for

### SCN-028: Domain determination by creating own domains

**Scenario Id:** SCN-028

**Objective:** Verify system allows user to determine domains by creating own domains (preserving TBD note regarding applicability to MM5/WRF).

**Scenario Type:** positive

**Preconditions:** ["User is in job setup domain determination step."]

**Requirement Ids:** ["REQ-022"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: JOBID. 5. User determines domains (TBD): • creates own domains (Note: This may only apply to MM5 jobs. From earlier discussions: creating domain files for

### SCN-029: Domain determination by choosing pre-defined domains

**Scenario Id:** SCN-029

**Objective:** Verify system allows user to determine domains by choosing from pre-defined domains.

**Scenario Type:** positive

**Preconditions:** ["User is in job setup domain determination step."]

**Requirement Ids:** ["REQ-022"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: WRF takes a long time.) or • chooses between a number of pre-defined domains or • submits own TERRAIN files 6. User defines when a

### SCN-030: Domain determination by submitting own TERRAIN files

**Scenario Id:** SCN-030

**Objective:** Verify system allows user to determine domains by submitting own TERRAIN files.

**Scenario Type:** positive

**Preconditions:** ["User is in job setup domain determination step and possesses valid TERRAIN files."]

**Requirement Ids:** ["REQ-022"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: WRF takes a long time.) or • chooses between a number of pre-defined domains or • submits own TERRAIN files 6. User defines when a

### SCN-031: Define job execution time and future/current cycle run

**Scenario Id:** SCN-031

**Objective:** Verify user can define when a job is to be run and/or what cycle to run for non-past cycle times.

**Scenario Type:** positive

**Preconditions:** ["User is in job timing/cycle definition step during job setup."]

**Requirement Ids:** ["REQ-023"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: WRF takes a long time.) or • chooses between a number of pre-defined domains or • submits own TERRAIN files 6. User defines when a
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: job is to be run and/or what cycle to run. If the cycle time is in the past, then the user is prompted to specify

### SCN-032: Prompt user for 'case study' or 're-run' when cycle time is in the past

**Scenario Id:** SCN-032

**Objective:** Verify that specifying a past cycle time triggers a system prompt asking the user to specify if the job is a 'case study' or 're-run'.

**Scenario Type:** boundary

**Preconditions:** ["User is in job schedule configuration."]

**Requirement Ids:** ["REQ-023"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: job is to be run and/or what cycle to run. If the cycle time is in the past, then the user is prompted to specify
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: whether the job is a “case study” or “re-run”. 7. User supplies other job specific information, such as, cycle interval, forecast length and other applicable

### SCN-033: Supply job-specific parameters including cycle interval and forecast length

**Scenario Id:** SCN-033

**Objective:** Verify system allows user to supply job-specific information such as cycle interval, forecast length, and other applicable information.

**Scenario Type:** positive

**Preconditions:** ["User is in job parameters specification stage of job setup."]

**Requirement Ids:** ["REQ-024"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: whether the job is a “case study” or “re-run”. 7. User supplies other job specific information, such as, cycle interval, forecast length and other applicable
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: information. 8. User can specify whether to write restart files and the frequency of how often they are to be written (TBD: Is this a

### SCN-034: Configure Restart File Writing and Frequency

**Scenario Id:** SCN-034

**Objective:** Verify that the user can specify whether restart files are written and set the writing frequency.

**Scenario Type:** positive

**Preconditions:** ["User is logged into the system and setting up a GMOD job in the Job-Setup module."]

**Requirement Ids:** ["REQ-025"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: information. 8. User can specify whether to write restart files and the frequency of how often they are to be written (TBD: Is this a
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: correct statement and does frequency only apply to WRF?). 9. User can choose between predefined sigma-level configurations or supply own sigma- level configuration 10.User has

### SCN-035: Configure Predefined vs Custom Sigma-Level Configuration

**Scenario Id:** SCN-035

**Objective:** Verify that the user can choose between predefined sigma-level configurations or supply a custom configuration.

**Scenario Type:** positive

**Preconditions:** ["User is in the Job-Setup configuration workflow."]

**Requirement Ids:** ["REQ-026"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: correct statement and does frequency only apply to WRF?). 9. User can choose between predefined sigma-level configurations or supply own sigma- level configuration 10.User has

### SCN-036: Specify Job Node Count

**Scenario Id:** SCN-036

**Objective:** Verify that the system allows the user to specify the number of nodes for job execution.

**Scenario Type:** positive

**Preconditions:** ["User is configuring resources in Job-Setup."]

**Requirement Ids:** ["REQ-027"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: correct statement and does frequency only apply to WRF?). 9. User can choose between predefined sigma-level configurations or supply own sigma- level configuration 10.User has
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: the option to specify the number of nodes to use. 11.User can choose to receive email notification upon start, end and termination of the job.

### SCN-037: Configure Job Email Notifications

**Scenario Id:** SCN-037

**Objective:** Verify that the user can opt to receive email notifications upon job start, end, and termination.

**Scenario Type:** positive

**Preconditions:** ["User is setting up job notifications."]

**Requirement Ids:** ["REQ-028"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: the option to specify the number of nodes to use. 11.User can choose to receive email notification upon start, end and termination of the job.

### SCN-038: Select Standard IC/BC Data Source

**Scenario Id:** SCN-038

**Objective:** Verify selection among standard IC/BC data sources (ETA, AVNFTP (GFS), GFS004).

**Scenario Type:** positive

**Preconditions:** ["User is performing IC/BC data selection in Job-Setup."]

**Requirement Ids:** ["REQ-029"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: 12.User chooses between standard or custom IC/BC data sources: • standard: ETA, AVNFTP (GFS), GFS004 or • custom: provide data source (e.g., host:Full_Path_to_Dir) or •
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: IC/BC data source and standard pre-processors. 11.Depending on the choice above, user can provide custom IC/BC pre-processor or choose the standard: • standard processing or

### SCN-039: Specify Custom IC/BC Data Source

**Scenario Id:** SCN-039

**Objective:** Verify specifying custom IC/BC data sources with host and full path.

**Scenario Type:** positive

**Preconditions:** ["User is configuring custom IC/BC sources in Job-Setup."]

**Requirement Ids:** ["REQ-029"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: 12.User chooses between standard or custom IC/BC data sources: • standard: ETA, AVNFTP (GFS), GFS004 or • custom: provide data source (e.g., host:Full_Path_to_Dir) or •

### SCN-040: Off-Line Job IC/BC Location and Time Period Specification

**Scenario Id:** SCN-040

**Objective:** Verify that off-line jobs require specifying the data source location (MetVault or directory) and time period.

**Scenario Type:** boundary

**Preconditions:** ["Job is configured as an off-line job."]

**Requirement Ids:** ["REQ-029"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: For off-line jobs, the user must specify the data source, i.e., location (MetVault or a directory) and time period. Important note for re-runs, if the
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: • etc. or • For off-line jobs, the user must specify the data source, i.e., location (MetVault or a directory) and time period. Important note

### SCN-041: Re-run Job Using MetVault Data Source

**Scenario Id:** SCN-041

**Objective:** Verify that for re-runs using MetVault, MetVault returns the data available and used in that cycle.

**Scenario Type:** state_transition

**Preconditions:** ["Job is designated as a re-run for a cycle in the past."]

**Requirement Ids:** ["REQ-029"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: For off-line jobs, the user must specify the data source, i.e., location (MetVault or a directory) and time period. Important note for re-runs, if the
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: input data is to obtain from the MetVault, then MetVault returns the data that was available and used in that cycle. • TBD: Determine standard
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: • etc. or • For off-line jobs, the user must specify the data source, i.e., location (MetVault or a directory) and time period. Important note
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: for re-runs, if the input data is to obtain from the MetVault, then MetVault returns the data that was available and used in that cycle.

### SCN-042: Select Standard vs Custom IC/BC Pre-processor Script

**Scenario Id:** SCN-042

**Objective:** Verify that the user can choose standard pre-processing or provide a custom IC/BC pre-processing script.

**Scenario Type:** positive

**Preconditions:** ["IC/BC data source selection step is completed in Job-Setup."]

**Requirement Ids:** ["REQ-030"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: IC/BC data source and standard pre-processors. 11.Depending on the choice above, user can provide custom IC/BC pre-processor or choose the standard: • standard processing or
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: • provide own pre-processing script

### SCN-043: User Responsibility for Custom Assets Residence on Target Clusters

**Scenario Id:** SCN-043

**Objective:** Verify that when submitting a custom GMOD job, custom scripts, executables, and related assets reside on target execution clusters.

**Scenario Type:** positive

**Preconditions:** ["User is submitting a 'custom' GMOD job."]

**Requirement Ids:** ["REQ-031"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: Functional Requirements Specification for the Model Manager Page 5 MM's Job-Setup module will allow the user to substitute the default configuration, but it is the
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: user's responsibility to make sure that these scripts, executables, etc. reside on the cluster or clusters where the job will be running on. Submitting a

### SCN-044: Run Additional IC/BC Pre-processors Option

**Scenario Id:** SCN-044

**Objective:** Verify options to run additional IC/BC pre-processors (such as LDAS), supply a custom pre-processor/script, or skip.

**Scenario Type:** positive

**Preconditions:** ["User is in Model Manager step for additional IC/BC pre-processor configuration."]

**Requirement Ids:** ["REQ-032"]

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: • provide own pre-processing script
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Functional Requirements Specification for the Model Manager Page 6 12.User is given the option to run additional pre-processors for the IC/BC data, such as, LDAS
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: or supply own custom pre-processor or skip this option. 13.User chooses between standard and/or custom obs data sources and processing: • Standard: WMO, SAMS, MADIS,

### SCN-045: Configure observational data sources and processing

**Scenario Id:** SCN-045

**Objective:** Verify the user can select standard observational data sources, provide custom observational sources and custom observational processors, or choose both.

**Scenario Type:** positive

**Preconditions:** ["User is navigating the observational data configuration section in Model Manager."]

**Requirement Ids:** ["REQ-033"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: or supply own custom pre-processor or skip this option. 13.User chooses between standard and/or custom obs data sources and processing: • Standard: WMO, SAMS, MADIS,
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: GTS, RAWS, okmeso, SatWinds, ACARS, etc. and/or • provide custom obs source1 and custom obs processor1 • provide custom obs source2 and custom obs processor2

### SCN-046: Select compiled standard MM5 executable based on domain size and node count

**Scenario Id:** SCN-046

**Objective:** Verify system presents compiled standard MM5 executables based on domain size and node count, accounting for the unresolved ambiguity regarding the exact definition of a standard MM5 executable.

**Scenario Type:** positive

**Preconditions:** ["MM5 model is selectable and prior domain size and node count decisions exist."]

**Requirement Ids:** ["REQ-034"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: the user: • MM5: The domain size and number of nodes for this job was determined earlier. Based on both choices, the user is presented
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: with different MM5-executables to choose from. These executables have been compiled in advanced. The MM will be able to retrieve the compile info about the
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: executables, e.g., domain size, number of nodes, number of sigma levels, etc. These few executables are standard executables (TBD: determine what 'standard MM5 executable’ means).

### SCN-047: Supply user custom executable for MM5 model

**Scenario Id:** SCN-047

**Objective:** Verify the user can supply a custom executable (e.g., specifying its cluster location) when MM5 model is chosen.

**Scenario Type:** positive

**Preconditions:** ["MM5 model is selected."]

**Requirement Ids:** ["REQ-034"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Or, the user can also supply own executable, e.g., its location on the cluster • WRF: User defines model options (TBD: determine possible model options)

### SCN-048: Define model options for WRF model

**Scenario Id:** SCN-048

**Objective:** Verify system allows user to define model options when the WRF model is chosen, explicitly preserving the TBD ambiguity on possible WRF options.

**Scenario Type:** positive

**Preconditions:** ["User is selecting model options in Model Manager."]

**Requirement Ids:** ["REQ-035"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Or, the user can also supply own executable, e.g., its location on the cluster • WRF: User defines model options (TBD: determine possible model options)

### SCN-049: Configure Final Analysis run option

**Scenario Id:** SCN-049

**Objective:** Verify user can choose whether or not to run Final Analysis, preserving that this option may only apply to re-runs and case studies.

**Scenario Type:** positive

**Preconditions:** ["Job context is configured (e.g., re-run or case study context where applicable)."]

**Requirement Ids:** ["REQ-036"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: 15.User chooses whether or not to run Final Analysis. This may only apply to re-runs and case studies. 16.User chooses whether or not to run

### SCN-050: Configure Preliminary Analysis run option

**Scenario Id:** SCN-050

**Objective:** Verify user can choose whether or not to run Preliminary Analysis, preserving that this option may only apply to re-runs and case studies.

**Scenario Type:** positive

**Preconditions:** ["Job context is configured (e.g., re-run or case study context where applicable)."]

**Requirement Ids:** ["REQ-037"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: 15.User chooses whether or not to run Final Analysis. This may only apply to re-runs and case studies. 16.User chooses whether or not to run
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Prelim. Analysis. This may only apply to re-runs and case studies. 17.User chooses whether or not run additional processing on the model output. (TBD: What

### SCN-051: Configure additional processing on model output

**Scenario Id:** SCN-051

**Objective:** Verify user can choose whether or not to run additional processing on model output, noting exact processing options (e.g., Bias Correction) are TBD.

**Scenario Type:** positive

**Preconditions:** ["Model output options step is active."]

**Requirement Ids:** ["REQ-038"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Prelim. Analysis. This may only apply to re-runs and case studies. 17.User chooses whether or not run additional processing on the model output. (TBD: What
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: exactly are the options for additional processing? Bias Correction?) 18.User can choose to save the model output in MetVault. If 'yes', user must specify what

### SCN-052: Save model output in MetVault with file specification requirement

**Scenario Id:** SCN-052

**Objective:** Verify user can choose to save model output in MetVault and is required to specify which output file is sent when 'yes' is selected.

**Scenario Type:** positive

**Preconditions:** ["Job output save options are accessible."]

**Requirement Ids:** ["REQ-039"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: exactly are the options for additional processing? Bias Correction?) 18.User can choose to save the model output in MetVault. If 'yes', user must specify what
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: output file is to be sent to the MetVault. 19.User is given the option to save and submit the job now. Submitting now, would run
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: chooses whether or not run additional processing on the model output. (TBD: Is 10. applicable to ClimoFDDA jobs? 11.User can choose to save the model
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: output in MetVault. If 'yes', user must specify what output, e.g., member and/or ensemble output is to be send to the MetVault. 12.User is given

### SCN-053: Save and submit job immediately without post-processing

**Scenario Id:** SCN-053

**Objective:** Verify system provides immediate save and submit option, which executes IC/BC-data processing, observational processing, and the model, but excludes post-processing.

**Scenario Type:** positive

**Preconditions:** ["Job setup parameters for IC/BC, observational data, and model options are configured."]

**Requirement Ids:** ["REQ-040"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: output file is to be sent to the MetVault. 19.User is given the option to save and submit the job now. Submitting now, would run
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: IC/BC-data and obs processing and the model, no post-processing. 20.User chooses whether or not to run post-processing. If ‘yes', then s/he will go through the

### SCN-054: Select ClimoFDDA job setup from new model job options

**Scenario Id:** SCN-054

**Objective:** Verify that a logged-on user selecting 'Submit a new job' -&gt; 'Set up a new model job' is presented with 'Weather FDDA' and 'Climo' options, and can initiate 'ClimoFDDA' job setup.

**Scenario Type:** positive

**Preconditions:** ["User is logged on to the system."]

**Requirement Ids:** ["REQ-044"]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: Functional Requirements Specification for the Model Manager Page 7 The objective of this feature is to integrate the GCAT functionalities within the MM. Suppose the
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: user is logged on to the system and has made the following choices “Submit a new job” -&gt; “Set up a new model job”. S/he
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: is then presented with two more options: “ Weather FDDA” and “Climo”. Primary actor: Meteorologist, software engineer Goal: Set up and run a ClimoFDDA job.
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: At this point, the MM only supports “ClimoFDDA”. Action Sequence: 1. Chooses to “Set up a Climo Job”. 2. User defines a JOBID. 3. User

### SCN-055: Configure ClimoFDDA identification, domain, and location parameters

**Scenario Id:** SCN-055

**Objective:** Verify that during ClimoFDDA job setup, the user can define a JOBID, supply other job parameters, determine domain location, and specify locations for pseudo-obs and custom cross sections.

**Scenario Type:** positive

**Preconditions:** ["User has initiated ClimoFDDA job setup."]

**Requirement Ids:** ["REQ-045"]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: At this point, the MM only supports “ClimoFDDA”. Action Sequence: 1. Chooses to “Set up a Climo Job”. 2. User defines a JOBID. 3. User
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: supplies other job parameters. For details, see GCAT tool 4. User determines the domain location. 5. User can specify locations for pseudo-obs and custom cross
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: sections. (TBD: Is this configuration information that is only used during post-processing?) 6. User picks a pre-configured MM5 setup 7. User sets the time line

### SCN-056: Configure MM5 setup model and job timeline

**Scenario Id:** SCN-056

**Objective:** Verify that during ClimoFDDA job setup, the user can pick a pre-configured MM5 setup and set the job timeline (start time, end time, target years).

**Scenario Type:** positive

**Preconditions:** ["User is in the ClimoFDDA job setup workflow."]

**Requirement Ids:** ["REQ-046"]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: sections. (TBD: Is this configuration information that is only used during post-processing?) 6. User picks a pre-configured MM5 setup 7. User sets the time line
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: for the job: start time, end time and what years 8. User sets the ensemble options: • hourly (TBD: Are there other options? Daily?) •

### SCN-057: Configure ClimoFDDA ensemble options

**Scenario Id:** SCN-057

**Objective:** Verify that the user can set ensemble options including hourly frequency, statistical measures (min, max, mean, standard deviation, etc.), diurnal cycle, and typical moment during ClimoFDDA setup.

**Scenario Type:** positive

**Preconditions:** ["User is in the ClimoFDDA job setup workflow."]

**Requirement Ids:** ["REQ-047"]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: for the job: start time, end time and what years 8. User sets the ensemble options: • hourly (TBD: Are there other options? Daily?) •
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: min, max, mean, standard deviation,.... • diurnal cycle • typical moment 9. User can request the number of nodes this job should run on. 10.User

### SCN-058: Request cluster nodes for ClimoFDDA job

**Scenario Id:** SCN-058

**Objective:** Verify that the user can specify and request the number of cluster nodes on which the job should run.

**Scenario Type:** positive

**Preconditions:** ["User is in the ClimoFDDA job setup workflow."]

**Requirement Ids:** ["REQ-048"]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: min, max, mean, standard deviation,.... • diurnal cycle • typical moment 9. User can request the number of nodes this job should run on. 10.User

### SCN-059: Opt to run post-processing and proceed to section 3.4 action sequence

**Scenario Id:** SCN-059

**Objective:** Verify that selecting 'yes' for running post-processing redirects the user to the section 3.4 action sequence.

**Scenario Type:** state_transition

**Preconditions:** ["User is configuring post-processing options in the setup workflow."]

**Requirement Ids:** ["REQ-041"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: IC/BC-data and obs processing and the model, no post-processing. 20.User chooses whether or not to run post-processing. If ‘yes', then s/he will go through the
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: action sequence in 3.4. (TBD: How customizable should post-processing be? In GCAT, e.g., the user can specify locations for pseudo-soundings, cross sections, pseudo-obs, etc. Do

### SCN-060: Opt out of post-processing run

**Scenario Id:** SCN-060

**Objective:** Verify that selecting 'no' when prompted to run post-processing prevents proceeding to section 3.4 action sequence.

**Scenario Type:** positive

**Preconditions:** ["User is configuring post-processing options in the setup workflow."]

**Requirement Ids:** ["REQ-041"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: IC/BC-data and obs processing and the model, no post-processing. 20.User chooses whether or not to run post-processing. If ‘yes', then s/he will go through the

### SCN-061: Save job configuration to file

**Scenario Id:** SCN-061

**Objective:** Verify that the system allows the user to save the current job configuration to a file.

**Scenario Type:** positive

**Preconditions:** ["Job parameters have been configured in Model Manager."]

**Requirement Ids:** ["REQ-042"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: pre-configured post-processing options be sufficient?) 21.User can save the above job configuration. Job configurations can be saved to a file. 22.User submits the job. Use

### SCN-062: Submit job

**Scenario Id:** SCN-062

**Objective:** Verify that the system allows the user to submit the configured job for execution.

**Scenario Type:** positive

**Preconditions:** ["Job configuration is complete."]

**Requirement Ids:** ["REQ-043"]

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: pre-configured post-processing options be sufficient?) 21.User can save the above job configuration. Job configurations can be saved to a file. 22.User submits the job. Use

### SCN-063: Select Set up a Climo Job during ClimoFDDA setup

**Scenario Id:** SCN-063

**Objective:** Verify that the user can select 'Set up a Climo Job' when configuring a ClimoFDDA job.

**Scenario Type:** positive

**Preconditions:** ["User is logged on to the system and in the Model Manager interface."]

**Requirement Ids:** ["REQ-052"]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: At this point, the MM only supports “ClimoFDDA”. Action Sequence: 1. Chooses to “Set up a Climo Job”. 2. User defines a JOBID. 3. User

### SCN-064: Configure model output additional processing option for ClimoFDDA job

**Scenario Id:** SCN-064

**Objective:** Verify system behavior when selecting whether or not to run additional processing on model output, maintaining TBD applicability status.

**Scenario Type:** positive

**Preconditions:** ["User has initiated 'Set up a Climo Job' in ClimoFDDA setup."]

**Requirement Ids:** ["REQ-049"]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: chooses whether or not run additional processing on the model output. (TBD: Is 10. applicable to ClimoFDDA jobs? 11.User can choose to save the model

### SCN-065: Save and submit ClimoFDDA job immediately without post-processing

**Scenario Id:** SCN-065

**Objective:** Verify immediate save and submission of a ClimoFDDA job executing member models, ensemble, and possible model output processing, but excluding post-processing.

**Scenario Type:** positive

**Preconditions:** ["User has configured base parameters (JOBID, time line, ensemble options) for a ClimoFDDA job."]

**Requirement Ids:** ["REQ-050"]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: the option to save and submit the job now. Submitting now, would run the member models, the ensemble, and possible model output processing, no post-
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: processing. 13.User chooses whether or not to run post-processing on the ensemble output. If “yes', then s/he will be presented with the following options: •

### SCN-066: Configure ensemble output post-processing products and destination specifications

**Scenario Id:** SCN-066

**Objective:** Verify selection of post-processing on ensemble output and specification of destination host and location for each product.

**Scenario Type:** positive

**Preconditions:** ["User is in the post-processing section of ClimoFDDA job setup."]

**Requirement Ids:** ["REQ-051"]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: processing. 13.User chooses whether or not to run post-processing on the ensemble output. If “yes', then s/he will be presented with the following options: •
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: Plots (NCL or RIP) • NAPS • MDV • Sites • MEDOC (1 – 4) (?) • Raster • PRF • Wind Roses • ...
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: For each output product, the user is prompted to supply a destination host and location, where the output files should be copied.

### SCN-067: Decline post-processing on ensemble output

**Scenario Id:** SCN-067

**Objective:** Verify system behavior when the user selects 'no' for post-processing on ensemble output.

**Scenario Type:** negative

**Preconditions:** ["User is in the post-processing section of ClimoFDDA job setup."]

**Requirement Ids:** ["REQ-051"]

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: processing. 13.User chooses whether or not to run post-processing on the ensemble output. If “yes', then s/he will be presented with the following options: •

### SCN-068: Specify post-processing settings for member models output

**Scenario Id:** SCN-068

**Objective:** Verify user specification of year-output to post-process, post-processor(s) to use, and target output copy location for member models.

**Scenario Type:** positive

**Preconditions:** ["User is in the Job Setup interface."]

**Requirement Ids:** ["REQ-053"]

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: Functional Requirements Specification for the Model Manager Page 8 14.The user can also specify whether the members' output should be post-processed. S/he can specify which
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: year-output to post-process and what post-processor(s) to use and where the output files should be copied. 15. The user can specify whether another process (coupled

### SCN-069: Specify coupled application execution on post-process output products

**Scenario Id:** SCN-069

**Objective:** Verify specification of running another process (coupled app) on post-process output products, preserving unresolved clarification requirement.

**Scenario Type:** positive

**Preconditions:** ["User is in Job Setup with post-processing options active."]

**Requirement Ids:** ["REQ-054"]

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: year-output to post-process and what post-processor(s) to use and where the output files should be copied. 15. The user can specify whether another process (coupled
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: app) should be run on the post-process output products. This needs further clarification. 16.User can save the above job configuration. Job configurations can be saved

### SCN-070: Save job configuration to a file

**Scenario Id:** SCN-070

**Objective:** Verify that the user can save the configured job setup to a file.

**Scenario Type:** positive

**Preconditions:** ["User is in Job Setup with an active configuration."]

**Requirement Ids:** ["REQ-055"]

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: app) should be run on the post-process output products. This needs further clarification. 16.User can save the above job configuration. Job configurations can be saved
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: to a file. 17.User submits the job. Use Case “CAM”: Setting up a CAM job TBD 3.2 Set up and submit a “post-processing” job The

### SCN-071: Submit configured post-processing job

**Scenario Id:** SCN-071

**Objective:** Verify that the user can submit the fully configured job.

**Scenario Type:** positive

**Preconditions:** ["Job setup parameters are fully configured."]

**Requirement Ids:** ["REQ-056"]

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: to a file. 17.User submits the job. Use Case “CAM”: Setting up a CAM job TBD 3.2 Set up and submit a “post-processing” job The

### SCN-072: Set up and submit post-processing job using future FDDA-job output

**Scenario Id:** SCN-072

**Objective:** Verify complete post-processing job setup workflow using an FDDA JOBID &amp; cycle time, selecting post-processing types, providing custom configuration, setting destination location and node count, saving settings, and submitting.

**Scenario Type:** positive

**Preconditions:** ["User is logged on to the Model Manager system and has initiated job creation."]

**Requirement Ids:** ["REQ-057", "REQ-058", "REQ-059", "REQ-060", "REQ-061", "REQ-062", "REQ-063", "REQ-064"]

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: new job”. Primary actor: Meteorologist, software engineer Goal: Run post-processing on model output Action Sequence: 1. User selects “Set up a new 'post-processing' job” .
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: 2. User is prompted to supply location and name of the model output file: • If the model output file will be produced by a
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: running or scheduled FDDA-job, then the user supplies JOBID &amp; cycle time • If the model output file already exists, then the user supplies its
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: location. 3. User chooses the type of post-processing: • Plots (NCL or RIP) • NAPS • MDV • Sites • MEDOC (1 – 4) (?)
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: • Stereo • Verification 4. For each of the options chosen in 3., the user can supply a custom configuration file (if this is applicable)
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: or use the default configuration file. 5. User must supply destination location for the output products. 6. User can specify the number of nodes this
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: job should run on (TBD: Is this a correct requirement?) 7. User can save this job's setting. Job configurations can be saved to a file.
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: Functional Requirements Specification for the Model Manager Page 9 8. User submits job. 3.3 Submit a 'By-hand' job The objective of this feature is to

### SCN-073: Set up post-processing job using an existing model output file with default configurations

**Scenario Id:** SCN-073

**Objective:** Verify post-processing job setup when specifying an existing model output file location and utilizing default configuration files for chosen options.

**Scenario Type:** positive

**Preconditions:** ["User is logged on to the system and an existing model output file is available at a reachable path."]

**Requirement Ids:** ["REQ-057", "REQ-058", "REQ-059", "REQ-060", "REQ-061", "REQ-064"]

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: new job”. Primary actor: Meteorologist, software engineer Goal: Run post-processing on model output Action Sequence: 1. User selects “Set up a new 'post-processing' job” .
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: 2. User is prompted to supply location and name of the model output file: • If the model output file will be produced by a
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: running or scheduled FDDA-job, then the user supplies JOBID &amp; cycle time • If the model output file already exists, then the user supplies its
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: location. 3. User chooses the type of post-processing: • Plots (NCL or RIP) • NAPS • MDV • Sites • MEDOC (1 – 4) (?)
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: • Stereo • Verification 4. For each of the options chosen in 3., the user can supply a custom configuration file (if this is applicable)
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: or use the default configuration file. 5. User must supply destination location for the output products. 6. User can specify the number of nodes this
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: Functional Requirements Specification for the Model Manager Page 9 8. User submits job. 3.3 Submit a 'By-hand' job The objective of this feature is to

### SCN-074: Complete creation, saving, submission, queue view, and email notification flow for a By-hand job

**Scenario Id:** SCN-074

**Objective:** Verify that a user can select 'Submit a By Hand Job', supply mandatory and optional fields, save settings to a file, submit the job, view it in the queue, and receive status email notifications.

**Scenario Type:** positive

**Preconditions:** ["User is logged on to the system and has selected 'Submit a new job'."]

**Requirement Ids:** ["REQ-065", "REQ-066", "REQ-067", "REQ-068", "REQ-069", "REQ-070", "REQ-071"]

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: 1. User selects “Submit a 'By Hand' Job” 2. User supplies: Mandatory: • job id (GMUAE, GWDPG,...) • location of the script (host:/full_path_to_script) • time
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: when to run the script • estimated time of how long the script will run • name(s) of executable(s) • max. runtime for the executable(s)
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: • number of nodes (??) • location of output products (such as: host:/dir_path) Optional: • frequency of how often the script should run • job
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: type • any additional information 3. User can save the job's settings. Job configurations can be saved to a file. 4. User submits job. 5.
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: User can view his/her job in the job queue (see 3.1.). 6. User can receive an email notification when job is started, finished or killed.

### SCN-075: Verification of Custom job completion notification to Model Manager

**Scenario Id:** SCN-075

**Objective:** Verify that upon completion, a custom job successfully sends a completion notification to the Model Manager.

**Scenario Type:** state_transition

**Preconditions:** ["A 'custom' job is submitted and actively running on the system."]

**Requirement Ids:** ["REQ-072"]

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: (SRS Note: 'custom' job will need to notify the MM when done.) 3.4 Load a job configuration from a file and submit the job The

### SCN-076: Load, modify, save, and submit a job configuration file

**Scenario Id:** SCN-076

**Objective:** Verify that a user can select 'Submit a job configuration file', supply a file name to load it into MM, make changes, save the updated configuration, and submit the job.

**Scenario Type:** positive

**Preconditions:** ["The user is logged on to the system."]

**Requirement Ids:** ["REQ-073", "REQ-074", "REQ-075", "REQ-076", "REQ-077"]

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: to the system and has made the following choice, “Submit a new job”. Primary actor: Meteorologist, software engineer Action Sequence: 1. User selects ”Submit a
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: ”Submit a job configuration file”.
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: Functional Requirements Specification for the Model Manager Page 10 2. User supplies file name to load. 3. User can make changes to the configuration. 4.
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: User can save the changed configuration. 5. User submits the job. 3.5 Retrieve and run a previously saved job configuration The objective of this feature
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: job configuration. 4. User changes the job configuration. 5. User can save the changed job configuration. 6. User submits job. 3.6 View scheduled, running and

### SCN-077: Log on, view previously saved job configurations table, select, modify, and delete a job configuration

**Scenario Id:** SCN-077

**Objective:** Verify that a user can log on with user ID and password, view saved job configurations in a table, select a job, and either change or delete the configuration.

**Scenario Type:** positive

**Preconditions:** ["At least one previously saved job configuration exists for the user."]

**Requirement Ids:** ["REQ-078", "REQ-079", "REQ-080"]

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: actor: Meteorologist, software engineer Goal: Run a previously configured job. Action Sequence: 1. User logs on with user id/password. 2. User chooses to look at
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: his/her previously saved job configurations. A table of saved jobs may include the following attributes: • Job id • Job type • Cycle time that
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: was run last (if applicable) • time this job was run last • ... 3. User selects a job. User can change or delete this
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: job configuration. 4. User changes the job configuration. 5. User can save the changed job configuration. 6. User submits job. 3.6 View scheduled, running and

### SCN-078: Submit job from retrieved or changed job configuration

**Scenario Id:** SCN-078

**Objective:** Verify that a user can submit a job after retrieving a saved configuration directly or after modifying it.

**Scenario Type:** positive

**Preconditions:** ["User is logged into the Model Manager system.", "Saved job configurations exist for the user."]

**Requirement Ids:** ["REQ-081"]

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: job configuration. 4. User changes the job configuration. 5. User can save the changed job configuration. 6. User submits job. 3.6 View scheduled, running and

### SCN-079: Log on to monitor running, scheduled, or past jobs

**Scenario Id:** SCN-079

**Objective:** Verify that a user (e.g., Meteorologist or software engineer) can log on using user ID and password to access job monitoring and history.

**Scenario Type:** positive

**Preconditions:** ["User account exists with valid credentials."]

**Requirement Ids:** ["REQ-082"]

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: past. Primary actor: Meteorologist, software engineer Goal: Monitor a running job and view scheduled and old jobs Action Sequence: 1. User logs on with user
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: id/password. 2. User chooses to look at all running jobs, all scheduled jobs (the job queue), past jobs or all jobs (running, scheduled, old). User

### SCN-080: Select job viewing options for running, scheduled, past, or all jobs

**Scenario Id:** SCN-080

**Objective:** Verify that selecting each of the four job viewing options displays the corresponding filtered job set.

**Scenario Type:** positive

**Preconditions:** ["User is logged on to the job viewing interface.", "Jobs in running, scheduled, and completed states exist in the system."]

**Requirement Ids:** ["REQ-083"]

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: id/password. 2. User chooses to look at all running jobs, all scheduled jobs (the job queue), past jobs or all jobs (running, scheduled, old). User
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: selects one of the four options. 3. User is presented with a job table. Depending on the user's choice in 2, the job table may

### SCN-081: Display job table with user ID owner attribute

**Scenario Id:** SCN-081

**Objective:** Verify that the presented job table displays job attributes including user ID as the owner of the job based on the selected viewing option.

**Scenario Type:** positive

**Preconditions:** ["User is logged on to the job viewing section."]

**Requirement Ids:** ["REQ-084"]

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: selects one of the four options. 3. User is presented with a job table. Depending on the user's choice in 2, the job table may
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: present the following attributes to the user: • user id – the 'owner' of the job

### SCN-082: Identify clusters, setup, and register custom job for By-hand submission

**Scenario Id:** SCN-082

**Objective:** Verify the complete sequence for submitting a custom By-hand job including cluster identification, target login, setup, and registration with MM.

**Scenario Type:** positive

**Preconditions:** ["User has access credentials to target cluster machines and Model Manager."]

**Requirement Ids:** ["REQ-085"]

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: accommodate the current GMOD-framework. It will also give the user the ability to run customized jobs. In order to submit a custom job to the
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: MM, the user must first identify the cluster(s), where his/her job should run on. Then, log on to this machine, perform operations that are necessary
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: for setting up the job and then register the job with the MM (see Action Sequence below). It is important to note that since a

### SCN-083: Display complete set of standard job attributes in Model Manager

**Scenario Id:** SCN-083

**Objective:** Verify that Model Manager presents all specified mandatory job attributes including status, stage, cluster and nodes (for running jobs), and processor counts.

**Scenario Type:** positive

**Preconditions:** ["Jobs of various types and states are present in the system.", "User is logged into Model Manager."]

**Requirement Ids:** ["REQ-086"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: Functional Requirements Specification for the Model Manager Page 11 • Job id • Job type – such as: GMOD, climoFDDA, FDDA-re-run, case study, custom,.... •
- PDF p. 13, , `p0013-c001-139ddec67a27`: Job priority (TBD: How should jobs be prioritized?) • start time • remaining time (estimated) or time it took to run the job • cycle
- PDF p. 13, , `p0013-c001-139ddec67a27`: (if applicable) • stage (Pre-processing, F-analysis, Prelim. Analysis,...) • status ( SCHEDULED, RUNNING, status in % - if applicable, DONE) • cluster and nodes (for
- PDF p. 13, , `p0013-c001-139ddec67a27`: a running job) • number of processors • and others 4. User can select a job and receive more detailed information (TBD: What exactly are

### SCN-084: Select job to view detailed information

**Scenario Id:** SCN-084

**Objective:** Verify that selecting a specific job presents the detailed information view for that job.

**Scenario Type:** positive

**Preconditions:** ["User is viewing the job list in Model Manager."]

**Requirement Ids:** ["REQ-087"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: a running job) • number of processors • and others 4. User can select a job and receive more detailed information (TBD: What exactly are
- PDF p. 13, , `p0013-c001-139ddec67a27`: the details?) 5. User can look at a jobs log files. 6. User can delete his/her jobs from the job queue. A “super user” can

### SCN-085: View log files of a job

**Scenario Id:** SCN-085

**Objective:** Verify that a user can access and view log files associated with a selected job.

**Scenario Type:** positive

**Preconditions:** ["User is logged into Model Manager and viewing job details or options.", "Log files exist for the target job."]

**Requirement Ids:** ["REQ-088"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: the details?) 5. User can look at a jobs log files. 6. User can delete his/her jobs from the job queue. A “super user” can

### SCN-086: Standard User Delete Own Job from Queue

**Scenario Id:** SCN-086

**Objective:** Verify that a standard user can delete their own job from the job queue.

**Scenario Type:** positive

**Preconditions:** ["A standard user exists with an owned job currently in the job queue."]

**Requirement Ids:** ["REQ-089"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: the details?) 5. User can look at a jobs log files. 6. User can delete his/her jobs from the job queue. A “super user” can

### SCN-087: Super User Delete Any Job from Queue

**Scenario Id:** SCN-087

**Objective:** Verify that a super user can delete any job owned by another user from the job queue.

**Scenario Type:** positive

**Preconditions:** ["A super user exists.", "A job (Job B) owned by a standard user exists in the job queue."]

**Requirement Ids:** ["REQ-089"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: the details?) 5. User can look at a jobs log files. 6. User can delete his/her jobs from the job queue. A “super user” can
- PDF p. 13, , `p0013-c001-139ddec67a27`: delete any job from the job queue. 7. User can stop his/her running job. A “super user” can stop any running job. 8. User can

### SCN-088: Standard User Stop Own Running Job

**Scenario Id:** SCN-088

**Objective:** Verify that a standard user can stop their own currently running job.

**Scenario Type:** state_transition

**Preconditions:** ["A standard user exists with a job in the RUNNING state."]

**Requirement Ids:** ["REQ-090"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: delete any job from the job queue. 7. User can stop his/her running job. A “super user” can stop any running job. 8. User can

### SCN-089: Super User Stop Any Running Job

**Scenario Id:** SCN-089

**Objective:** Verify that a super user can stop any running job owned by another user.

**Scenario Type:** state_transition

**Preconditions:** ["A super user exists.", "A running job (Job D) owned by a standard user exists."]

**Requirement Ids:** ["REQ-090"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: delete any job from the job queue. 7. User can stop his/her running job. A “super user” can stop any running job. 8. User can

### SCN-090: Standard User Re-start Own Job

**Scenario Id:** SCN-090

**Objective:** Verify that a standard user can re-start their own job.

**Scenario Type:** state_transition

**Preconditions:** ["A standard user exists with an eligible job (Job E)."]

**Requirement Ids:** ["REQ-091"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### SCN-091: Super User Re-start Any Job

**Scenario Id:** SCN-091

**Objective:** Verify that a super user can re-start any job owned by another user.

**Scenario Type:** state_transition

**Preconditions:** ["A super user exists.", "A job (Job F) owned by a standard user exists in the system."]

**Requirement Ids:** ["REQ-091"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: delete any job from the job queue. 7. User can stop his/her running job. A “super user” can stop any running job. 8. User can
- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### SCN-092: Standard User Resume Own Stopped Job

**Scenario Id:** SCN-092

**Objective:** Verify that a standard user can resume their own stopped job.

**Scenario Type:** state_transition

**Preconditions:** ["A standard user exists with an owned job in a stopped state."]

**Requirement Ids:** ["REQ-092"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### SCN-093: Super User Resume Any Stopped Job

**Scenario Id:** SCN-093

**Objective:** Verify that a super user can resume any stopped job owned by another user.

**Scenario Type:** state_transition

**Preconditions:** ["A super user exists.", "A job (Job H) owned by a standard user exists in a stopped state."]

**Requirement Ids:** ["REQ-092"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### SCN-094: Owner Resumes Own Stopped Job

**Scenario Id:** SCN-094

**Objective:** Verify that a regular user can successfully resume a stopped job that they own.

**Scenario Type:** positive

**Preconditions:** ["The job is in a stopped state.", "The logged-in user is the owner of the stopped job."]

**Requirement Ids:** ["REQ-092"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### SCN-095: Super User Resumes Any Stopped Job

**Scenario Id:** SCN-095

**Objective:** Verify that a super user can successfully resume a stopped job owned by another user.

**Scenario Type:** positive

**Preconditions:** ["The job is in a stopped state.", "The logged-in user has 'super user' privileges.", "The stopped job is owned by a different user."]

**Requirement Ids:** ["REQ-092"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### SCN-096: Non-Super User Denied Resuming Another User's Stopped Job

**Scenario Id:** SCN-096

**Objective:** Verify that a non-super user attempting to resume a stopped job owned by another user is denied permission.

**Scenario Type:** negative

**Preconditions:** ["The job is in a stopped state.", "The logged-in user is a non-super user.", "The stopped job is owned by another user."]

**Requirement Ids:** ["REQ-092"]

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

## Test Cases (96)

### TC-001: Configure, Schedule, Run, Monitor, and Lifecycle Management of Model Jobs via MM

**Scenario Id:** SCN-001

**Requirement Ids:** ["REQ-001"]

**Priority:** P1

**Preconditions:** ["Model Manager environment is running and accessible."]

**Test Data:** {"job_name": "Test_Model_Job_01", "schedule_time": "Immediate"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Open the Model Manager tool and create a new model job configuration. | The job configuration interface opens and accepts configuration settings. |
| 2 | Schedule and execute the configured model job. | The job is successfully scheduled and transitions to running status. |
| 3 | Monitor the execution status of the running model job. | Real-time monitoring information and status updates for the job are displayed. |
| 4 | Issue a stop command to the running job. | The job stops execution and updates its state to stopped. |
| 5 | Issue a re-start/resume command on the stopped model job. | The job successfully re-starts/resumes execution. |

**Source evidence**

- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: NSAP project sponsors and management. 1.4 Project Scope The Model Manager is a software tool that will allow the user to configure, schedule, run, monitor,

### TC-002: Back End System Extension and Automated Node Job Execution

**Scenario Id:** SCN-002

**Requirement Ids:** ["REQ-002"]

**Priority:** P2

**Preconditions:** ["Model back end system is integrated with the Model Manager automated node management module."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Submit a model job requiring back-end node management through the Model Manager system. | Model Manager automatically handles setup and node allocation in the back end. |
| 2 | Observe the job execution and node management lifecycle during runtime. | The back end automatically runs and monitors the model job and manages cluster/system nodes without manual intervention. |

**Source evidence**

- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: and stop (and re-start /resume) model jobs. The primary goal of this project is to extend the current model back end system and to automate
- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: the setup, running and monitoring of model jobs. This will include a more automated node management system. 1.5 References [1] “4DWX on the Move (4DWX

### TC-003: Execute MM as Stand-alone Application

**Scenario Id:** SCN-003

**Requirement Ids:** ["REQ-003"]

**Priority:** P2

**Preconditions:** ["Model Manager is configured in stand-alone execution mode with MetVault integrations disabled/absent."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Launch Model Manager in an environment isolated from MetVault. | Model Manager starts up cleanly without requiring MetVault service endpoints or configurations. |
| 2 | Execute a model management operation (e.g., job setup and run). | The operation executes successfully in stand-alone mode. |

**Source evidence**

- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: to the current model back end. The MM is a stand- alone software tool, which will also be part of the 4DWX OTM system (see
- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: stand-alone application with no knowledge about a MetVault. The MM will be accessible from a web-based GUI and a command line tool. 2.2 Product Features

### TC-004: Execute MM in Conjunction with MetVault and 4DWX OTM System

**Scenario Id:** SCN-004

**Requirement Ids:** ["REQ-003"]

**Priority:** P2

**Preconditions:** ["MetVault service and 4DWX OTM system components are active and accessible."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Launch Model Manager in an environment integrated with MetVault and the 4DWX OTM system. | Model Manager establishes connectivity with MetVault and 4DWX OTM components. |
| 2 | Perform a joint job execution workflow with MetVault data interaction. | Model Manager runs in conjunction with MetVault successfully. |

**Source evidence**

- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: to the current model back end. The MM is a stand- alone software tool, which will also be part of the 4DWX OTM system (see
- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: Functional Requirements Specification for the Model Manager Page 3 The MM can run in conjunction with the MetVault, and it can also run as a

### TC-005: User Access via Web-Based GUI

**Scenario Id:** SCN-005

**Requirement Ids:** ["REQ-004"]

**Priority:** P1

**Preconditions:** ["Model Manager web service is hosted and network accessible."]

**Test Data:** {"access_url": "http://model-manager.local/gui"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Navigate to the Model Manager URL in a supported web browser. | The Model Manager web-based GUI loads successfully. |
| 2 | Interact with system navigation and perform job viewing via the web interface. | The GUI responds appropriately to user inputs and displays Model Manager options. |

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: stand-alone application with no knowledge about a MetVault. The MM will be accessible from a web-based GUI and a command line tool. 2.2 Product Features
- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: [1]). Command Line ToolModel ManagerMetVault Web-based GUI

### TC-006: User Access via Command Line Tool

**Scenario Id:** SCN-006

**Requirement Ids:** ["REQ-004"]

**Priority:** P1

**Preconditions:** ["Model Manager command line tool binary is installed and configured in system path."]

**Test Data:** {"cli_command": "mm-cli --status"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Open a terminal and execute the Model Manager command line utility with the status/help flag. | The command line interface returns valid system information and available commands. |
| 2 | Execute a job management command via the CLI tool. | Model Manager CLI processes the command and returns expected console output. |

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: stand-alone application with no knowledge about a MetVault. The MM will be accessible from a web-based GUI and a command line tool. 2.2 Product Features
- PDF p. 4, 1.3 Intended Audience, `p0004-c001-8a0dbfdfbf27`: [1]). Command Line ToolModel ManagerMetVault Web-based GUI

### TC-007: Submit a By-Hand Job

**Scenario Id:** SCN-007

**Requirement Ids:** ["REQ-005"]

**Priority:** P1

**Preconditions:** ["User is logged in to Model Manager."]

**Test Data:** {"executable_path": "/usr/bin/custom_model_exec", "submission_type": "by-hand"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Select the 'by-hand' job submission option in Model Manager. | The system presents the manual/by-hand job submission form. |
| 2 | Enter required executable details and submit the job. | The system accepts the submission and creates a running or queued 'by-hand' job. |

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: view the status of operational model runs, stop and restart existing jobs or set up and start a 'standard' model job. Submit a 'by-hand' job

### TC-008: Submit a Job Defined by a Configuration File

**Scenario Id:** SCN-008

**Requirement Ids:** ["REQ-005"]

**Priority:** P1

**Preconditions:** ["A valid job configuration file is prepared on the local/accessible system."]

**Test Data:** {"config_file": "sample_job_config.yaml"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Select the configuration file job submission option. | The system prompts for file upload or path specification. |
| 2 | Provide a valid job configuration file and submit. | The system parses the configuration file, validates parameters, and submits the job. |

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: view the status of operational model runs, stop and restart existing jobs or set up and start a 'standard' model job. Submit a 'by-hand' job

### TC-009: Retrieve a Previously Saved Job Configuration

**Scenario Id:** SCN-009

**Requirement Ids:** ["REQ-006"]

**Priority:** P2

**Preconditions:** ["At least one saved job configuration exists in the system database/storage."]

**Test Data:** {"saved_config_id": "CFG_SAVED_001"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Navigate to the configuration retrieval interface. | A list or search interface for saved job configurations is displayed. |
| 2 | Select and retrieve a target previously saved job configuration. | The saved configuration parameters are accurately retrieved and loaded into the editor/view. |

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a

### TC-010: Stop an Active Running Job

**Scenario Id:** SCN-010

**Requirement Ids:** ["REQ-007"]

**Priority:** P1

**Preconditions:** ["A model job is currently in 'RUNNING' state."]

**Test Data:** {"job_id": "JOB_RUNNING_101"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Identify an active running job in the system monitoring dashboard. | Job status shows as 'RUNNING'. |
| 2 | Execute the stop action on the running job. | The system sends termination signals to the job process and updates status to 'STOPPED'. |

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a

### TC-011: Start a New Job

**Scenario Id:** SCN-011

**Requirement Ids:** ["REQ-008"]

**Priority:** P1

**Preconditions:** ["Job configuration is complete and ready to run."]

**Test Data:** {"job_id": "JOB_READY_201"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Select a configured job that has not been executed yet. | Job details are visible with option to start. |
| 2 | Click or trigger the 'Start' command. | The job initiates execution and transitions status to 'RUNNING'. |

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a

### TC-012: Restart / Resume an Existing Job

**Scenario Id:** SCN-012

**Requirement Ids:** ["REQ-008"]

**Priority:** P1

**Preconditions:** ["An existing job is in a stopped or partially completed state."]

**Test Data:** {"job_id": "JOB_STOPPED_202"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Select an existing stopped or paused job. | Job is listed in 'STOPPED' or 'PAUSED' state. |
| 2 | Issue the restart/resume command for the job. | The job resumes execution from where it stopped or restarts processing, transitioning back to 'RUNNING'. |

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a

### TC-013: Change and save a job configuration

**Scenario Id:** SCN-013

**Requirement Ids:** ["REQ-009"]

**Priority:** P2

**Preconditions:** ["User is logged in.", "At least one saved job configuration exists."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Retrieve an existing job configuration in the system. | The job configuration parameters are displayed and accessible for editing. |
| 2 | Modify the configuration settings and select the save option. | The updated job configuration is successfully saved by the system (noting this capability is marked as optional in the source feature diagram). |

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: or a job defined by a configuration file Retrieve a prev. saved job configuration Stop a job Start the job (restart/resume) Change and save a
- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: job configuration (optional) Set up a new model or “post- processing” job Monitor running jobs

### TC-014: Set up a new model or post-processing job

**Scenario Id:** SCN-014

**Requirement Ids:** ["REQ-010"]

**Priority:** P1

**Preconditions:** ["User is logged in to the system."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Access the Job-Setup module and select the option to set up a new model job. | The system presents the setup interface for a new model job. |
| 2 | Access the Job-Setup module and select the option to set up a new post-processing job. | The system presents the setup interface for a new post-processing job. |

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: job configuration (optional) Set up a new model or “post- processing” job Monitor running jobs

### TC-015: Monitor running jobs in the system

**Scenario Id:** SCN-015

**Requirement Ids:** ["REQ-011"]

**Priority:** P1

**Preconditions:** ["User is logged in.", "One or more jobs are submitted or running on the system."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Navigate to the job monitoring feature. | The system displays the active status and details of running jobs. |

**Source evidence**

- PDF p. 5, 2.2 Product Features, `p0005-c001-d314fb36988e`: job configuration (optional) Set up a new model or “post- processing” job Monitor running jobs

### TC-016: Model Manager cluster decision making and node management for submitted job

**Scenario Id:** SCN-016

**Requirement Ids:** ["REQ-012"]

**Priority:** P1

**Preconditions:** ["Model Manager is controlling one or more clusters."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Submit a job to Model Manager without specifying a target cluster. | Model Manager automatically manages node allocation, management, and utilization, making the decision on which cluster(s) the job will run. |

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: MM will manage jobs on one or more clusters. Node allocation, management and utilization will be provided by the MM (SRS note: The MM provides
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: many and which clusters a MM is managing. S/he will submit a job to the MM and the MM will make the decision on what

### TC-017: User explicitly specifies target cluster during customized job setup

**Scenario Id:** SCN-017

**Requirement Ids:** ["REQ-013"]

**Priority:** P2

**Preconditions:** ["User is setting up a customized job in the Job-Setup module.", "Multiple target clusters are registered with the system."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Initiate setup of a customized job within the Job-Setup module. | An option to choose/specify a specific target cluster for the job is available to the user. |
| 2 | Select a specific target cluster and complete the job submission process. | The job is submitted targeted explicitly to the user-specified cluster. |

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: the user will need to have the option to specify what cluster his/her job should run on. Managing more than one cluster, will also allow
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: may choose a cluster where the job should run on. 3. User decides what model should be used: MM5 or WRF. 4. User defines a

### TC-018: Execute RTFDDA and climoFDDA ensembles across several clusters

**Scenario Id:** SCN-018

**Requirement Ids:** ["REQ-014"]

**Priority:** P2

**Preconditions:** ["Model Manager manages multiple available clusters."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Submit an RTFDDA ensemble job configured for multi-cluster execution. | The RTFDDA ensemble runs across several clusters. |
| 2 | Submit a climoFDDA ensemble job configured for multi-cluster execution. | The climoFDDA ensemble runs across several clusters. |

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: the user will need to have the option to specify what cluster his/her job should run on. Managing more than one cluster, will also allow
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: RTFDDA and climoFDDA ensembles to run across several clusters. Once a user is logged in into the system, s/he will be presented with the features

### TC-019: Main menu feature options presented upon user login

**Scenario Id:** SCN-019

**Requirement Ids:** ["REQ-015"]

**Priority:** P1

**Preconditions:** ["User possesses valid login credentials."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in to the system successfully. | The system presents main menu options for: 'Submit a new job', 'Retrieve saved job configurations', and 'View the job queue/monitor running jobs'. |

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: RTFDDA and climoFDDA ensembles to run across several clusters. Once a user is logged in into the system, s/he will be presented with the features
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: in 2.2: • Submit a new job • Retrieve saved job configurations • View the job queue/monitor running jobs A new job can be submitted

### TC-020: Submit new job via Job-Setup module, by-hand job, job configuration file, and re-submitting changed configuration

**Scenario Id:** SCN-020

**Requirement Ids:** ["REQ-016"]

**Priority:** P1

**Preconditions:** ["User is logged into the system.", "A previously saved job configuration exists for method 4.", "Submission options terminology is acknowledged as subject to change."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Set up a new model or post-processing job via Job-Setup module and submit it. | The job is submitted to Model Manager successfully. |
| 2 | Select and submit a 'by-hand' job. | The 'by-hand' job is submitted to Model Manager successfully. |
| 3 | Supply and submit a job configuration file. | The job defined by the configuration file is submitted to Model Manager successfully. |
| 4 | Retrieve a previously saved job configuration, modify it, and re-submit it. | The retrieved and modified job configuration is re-submitted to Model Manager successfully. |

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: in 2.2: • Submit a new job • Retrieve saved job configurations • View the job queue/monitor running jobs A new job can be submitted
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: to the MM four different ways: • The user can set up a new model or 'post-processing' job through the Job-Setup module and submit it
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: (3.1 and 3.2). • The user can submit a 'by-hand' job (3.3). • The user can submit a job by supplying a job configuration file
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: to the MM (3.4). • The user can retrieve a job configuration that was previously saved with the MM, change it and re-submit that job
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: (3.5). If the user chooses to submit a new job, s/he will be given the following options to choose from: • “Setup a new model

### TC-021: Verify new model job type options during job setup

**Scenario Id:** SCN-021

**Requirement Ids:** ["REQ-017"]

**Priority:** P2

**Preconditions:** ["User is logged on to the Model Manager system."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in to the system and navigate to 'Submit a new job' -&gt; 'Set up a new model job'. | The system presents two options to the user: 'Weather FDDA' and 'Climo'. |

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: MM's Job-Setup module. Suppose the user is logged on to the system and has made the following choices “Submit a new job” -&gt; “Set up
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: a new model job”. S/he is then presented with two more options: “ Weather FDDA” and “Climo”. Use Case “WeatherFDDA”: Setting up a real time

### TC-022: Submit RTFDDA ensemble job as a 'by hand' job

**Scenario Id:** SCN-022

**Requirement Ids:** ["REQ-018"]

**Priority:** P2

**Preconditions:** ["User is logged on and in job submission interface."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select the option to submit a 'by hand' RTFDDA ensemble job and submit. | The system accepts the RTFDDA ensemble job. |

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: case describes the set up of GMOD jobs, re-runs and case studies. At this point, RTFDDA ensemble jobs will be submitted to the MM as

### TC-023: Submit RTFDDA ensemble job through a job configuration file

**Scenario Id:** SCN-023

**Requirement Ids:** ["REQ-018"]

**Priority:** P2

**Preconditions:** ["User has a valid RTFDDA ensemble job configuration file."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select the option to submit an RTFDDA ensemble job through a job configuration file and submit. | The system accepts the RTFDDA ensemble job. |

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: case describes the set up of GMOD jobs, re-runs and case studies. At this point, RTFDDA ensemble jobs will be submitted to the MM as
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: 'by hand' jobs or through a job configuration file. The MM will provide a default GMOD job configuration, which can be changed by the user

### TC-024: Verify default GMOD job configuration provision and modification

**Scenario Id:** SCN-024

**Requirement Ids:** ["REQ-019"]

**Priority:** P1

**Preconditions:** ["User is in the Job-Setup module."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Open the GMOD job configuration interface in Job-Setup. | The system provides a default GMOD job configuration (noting defaults are marked TBD). |
| 2 | Modify the parameters in the default GMOD job configuration. | The system updates the configuration values according to user input. |

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: 'by hand' jobs or through a job configuration file. The MM will provide a default GMOD job configuration, which can be changed by the user
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: (TBD: Define the defaults for a GMOD job). It is important to note that the model manager will accept and run “custom” GMOD jobs. These

### TC-025: Set up, accept, run, and save custom GMOD job configuration with custom substitutions

**Scenario Id:** SCN-025

**Requirement Ids:** ["REQ-019"]

**Priority:** P1

**Preconditions:** ["User has created/provided necessary custom scripts, executables, or input data on the target cluster."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Through the Job-Setup module, create a GMOD job substituting defaults with user-supplied input data, pre-processors, or customized MM5 executables. | The Job-Setup module accepts the custom GMOD parameters. |
| 2 | Choose the option to save the custom GMOD job configuration. | The MM saves the custom job configuration. |
| 3 | Submit and execute the custom GMOD job. | The MM accepts and runs the custom GMOD job. |

**Source evidence**

- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: (TBD: Define the defaults for a GMOD job). It is important to note that the model manager will accept and run “custom” GMOD jobs. These
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: are jobs that are also set up through the Setup-module, but do not use the default GMOD configuration For a “custom” GMOD job, e.g., the
- PDF p. 6, 3.1 Set up and submit a model job, `p0006-c001-bb7294b4b8e0`: user may choose to supply his/her own input data, own pre-processors or a customized version of a MM5 executable.
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: Functional Requirements Specification for the Model Manager Page 5 MM's Job-Setup module will allow the user to substitute the default configuration, but it is the
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: “custom” GMOD job thought the Job-Setup module will allow the user to save the job's configuration with the MM. Primary actor: Meteorologist, software engineer Goal:

### TC-026: Model selection for Weather FDDA job (MM5 vs WRF)

**Scenario Id:** SCN-026

**Requirement Ids:** ["REQ-020"]

**Priority:** P1

**Preconditions:** ["User has selected Weather FDDA job setup option."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Initiate 'Set up a Weather FDDA Job' in the system. | The system presents model selection choices for MM5 and WRF. |
| 2 | Select 'MM5' as the model. | MM5 is set as the selected model. |
| 3 | Change model selection to 'WRF'. | WRF is set as the selected model. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: Set up and run a real time and off-line GMOD job Action Sequence: 1. User chooses to “Set up a Weather FDDA Job”. 2. User
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: may choose a cluster where the job should run on. 3. User decides what model should be used: MM5 or WRF. 4. User defines a

### TC-027: Define JOBID during Weather FDDA job set up

**Scenario Id:** SCN-027

**Requirement Ids:** ["REQ-021"]

**Priority:** P2

**Preconditions:** ["User is in Weather FDDA job setup sequence."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Navigate to the JOBID definition step in Weather FDDA job set up. | The system prompts for a JOBID. |
| 2 | Enter a JOBID string 'TEST_JOB_01'. | The system accepts and assigns 'TEST_JOB_01' as the JOBID. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: JOBID. 5. User determines domains (TBD): • creates own domains (Note: This may only apply to MM5 jobs. From earlier discussions: creating domain files for

### TC-028: Domain determination by creating own domains

**Scenario Id:** SCN-028

**Requirement Ids:** ["REQ-022"]

**Priority:** P1

**Preconditions:** ["User is in job setup domain determination step."]

| Step | Action | Expected result |
|---|---|---|
| 1 | In domain determination step, choose option to create own domains (noting domain determination specifics and WRF processing time applicability are marked TBD). | The system opens the domain creation workflow and allows defining domain parameters. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: JOBID. 5. User determines domains (TBD): • creates own domains (Note: This may only apply to MM5 jobs. From earlier discussions: creating domain files for

### TC-029: Domain determination by choosing pre-defined domains

**Scenario Id:** SCN-029

**Requirement Ids:** ["REQ-022"]

**Priority:** P1

**Preconditions:** ["User is in job setup domain determination step."]

| Step | Action | Expected result |
|---|---|---|
| 1 | In domain determination step, select the option to choose pre-defined domains. | The system displays the list of pre-defined domains. |
| 2 | Select a pre-defined domain from the list. | The system applies the selected pre-defined domain to the job. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: WRF takes a long time.) or • chooses between a number of pre-defined domains or • submits own TERRAIN files 6. User defines when a

### TC-030: Domain determination by submitting own TERRAIN files

**Scenario Id:** SCN-030

**Requirement Ids:** ["REQ-022"]

**Priority:** P1

**Preconditions:** ["User is in job setup domain determination step and possesses valid TERRAIN files."]

| Step | Action | Expected result |
|---|---|---|
| 1 | In domain determination step, select option to submit own TERRAIN files and upload TERRAIN file. | The system accepts the user-provided TERRAIN file for domain determination. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: WRF takes a long time.) or • chooses between a number of pre-defined domains or • submits own TERRAIN files 6. User defines when a

### TC-031: Define job execution time and future/current cycle run

**Scenario Id:** SCN-031

**Requirement Ids:** ["REQ-023"]

**Priority:** P1

**Preconditions:** ["User is in job timing/cycle definition step during job setup."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Specify job run time and/or cycle time for a current or future time. | The system accepts the run schedule and cycle configuration without prompting for historical job type. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: WRF takes a long time.) or • chooses between a number of pre-defined domains or • submits own TERRAIN files 6. User defines when a
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: job is to be run and/or what cycle to run. If the cycle time is in the past, then the user is prompted to specify

### TC-032: Prompt user for 'case study' or 're-run' when cycle time is in the past

**Scenario Id:** SCN-032

**Requirement Ids:** ["REQ-023"]

**Priority:** P1

**Preconditions:** ["User is in job schedule configuration."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Specify a cycle time that is in the past. | The system prompts the user to specify whether the job is a 'case study' or 're-run'. |
| 2 | Select 'case study' in response to the prompt. | The system records the job as a case study with the past cycle time. |
| 3 | Specify another past cycle time and select 're-run' when prompted. | The system records the job as a re-run with the past cycle time. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: job is to be run and/or what cycle to run. If the cycle time is in the past, then the user is prompted to specify
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: whether the job is a “case study” or “re-run”. 7. User supplies other job specific information, such as, cycle interval, forecast length and other applicable

### TC-033: Supply job-specific parameters including cycle interval and forecast length

**Scenario Id:** SCN-033

**Requirement Ids:** ["REQ-024"]

**Priority:** P2

**Preconditions:** ["User is in job parameters specification stage of job setup."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Navigate to the job parameters specification step during job setup. | The system displays input fields for cycle interval, forecast length, and other applicable information. |
| 2 | Input valid values for cycle interval, forecast length, and other applicable parameters. | The system accepts and saves the supplied job-specific parameters. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: whether the job is a “case study” or “re-run”. 7. User supplies other job specific information, such as, cycle interval, forecast length and other applicable
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: information. 8. User can specify whether to write restart files and the frequency of how often they are to be written (TBD: Is this a

### TC-034: Configure Restart File Writing and Frequency

**Scenario Id:** SCN-034

**Requirement Ids:** ["REQ-025"]

**Priority:** P3

**Preconditions:** ["User is logged into the system and setting up a GMOD job in the Job-Setup module."]

**Test Data:** {"ambiguity_note": "Statement correctness and whether frequency applies only to WRF are marked TBD.", "write_frequency": "6 hours", "enable_restart_files": true}

| Step | Action | Expected result |
|---|---|---|
| 1 | Navigate to the Job-Setup module restart file configuration section. | Options to enable restart file writing and specify output frequency are displayed. |
| 2 | Enable the option to write restart files and enter a specific writing frequency. | The system accepts the restart file writing selection and records the specified frequency. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: information. 8. User can specify whether to write restart files and the frequency of how often they are to be written (TBD: Is this a
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: correct statement and does frequency only apply to WRF?). 9. User can choose between predefined sigma-level configurations or supply own sigma- level configuration 10.User has

### TC-035: Configure Predefined vs Custom Sigma-Level Configuration

**Scenario Id:** SCN-035

**Requirement Ids:** ["REQ-026"]

**Priority:** P2

**Preconditions:** ["User is in the Job-Setup configuration workflow."]

**Test Data:** {"predefined_option": "Standard-40-Level", "custom_sigma_levels": "1.0, 0.99, 0.98, 0.95, 0.90, 0.0"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Select a predefined sigma-level configuration option in Job-Setup. | The selected predefined sigma-level configuration is applied. |
| 2 | Switch to supplying a custom sigma-level configuration and provide custom levels. | The system accepts the custom sigma-level configuration. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: correct statement and does frequency only apply to WRF?). 9. User can choose between predefined sigma-level configurations or supply own sigma- level configuration 10.User has

### TC-036: Specify Job Node Count

**Scenario Id:** SCN-036

**Requirement Ids:** ["REQ-027"]

**Priority:** P2

**Preconditions:** ["User is configuring resources in Job-Setup."]

**Test Data:** {"specified_node_count": 8}

| Step | Action | Expected result |
|---|---|---|
| 1 | Locate the node count input option during job setup. | The input field for node count is accessible. |
| 2 | Specify the desired number of nodes for the job. | The specified node count is saved as part of the job configuration. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: correct statement and does frequency only apply to WRF?). 9. User can choose between predefined sigma-level configurations or supply own sigma- level configuration 10.User has
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: the option to specify the number of nodes to use. 11.User can choose to receive email notification upon start, end and termination of the job.

### TC-037: Configure Job Email Notifications

**Scenario Id:** SCN-037

**Requirement Ids:** ["REQ-028"]

**Priority:** P2

**Preconditions:** ["User is setting up job notifications."]

**Test Data:** {"user_email": "user@example.com", "notify_on_end": true, "notify_on_start": true, "notify_on_termination": true}

| Step | Action | Expected result |
|---|---|---|
| 1 | Access the notification settings area in Job-Setup. | Email notification options for start, end, and termination events are available. |
| 2 | Select options to receive email notifications upon job start, end, and termination. | The notification choices are recorded for the job submission. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: the option to specify the number of nodes to use. 11.User can choose to receive email notification upon start, end and termination of the job.

### TC-038: Select Standard IC/BC Data Source

**Scenario Id:** SCN-038

**Requirement Ids:** ["REQ-029"]

**Priority:** P1

**Preconditions:** ["User is performing IC/BC data selection in Job-Setup."]

**Test Data:** {"ambiguity_note": "Standard IC/BC data source is marked TBD.", "selected_standard_source": "ETA"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Navigate to the IC/BC data source selection section in Job-Setup. | Standard IC/BC options including ETA, AVNFTP (GFS), and GFS004 are present. |
| 2 | Select 'ETA' as the standard IC/BC data source. | The system sets ETA as the job IC/BC data source. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: 12.User chooses between standard or custom IC/BC data sources: • standard: ETA, AVNFTP (GFS), GFS004 or • custom: provide data source (e.g., host:Full_Path_to_Dir) or •
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: IC/BC data source and standard pre-processors. 11.Depending on the choice above, user can provide custom IC/BC pre-processor or choose the standard: • standard processing or

### TC-039: Specify Custom IC/BC Data Source

**Scenario Id:** SCN-039

**Requirement Ids:** ["REQ-029"]

**Priority:** P1

**Preconditions:** ["User is configuring custom IC/BC sources in Job-Setup."]

**Test Data:** {"custom_host": "cluster-node01", "custom_full_path": "/data/custom_icbc_dir"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Select the custom IC/BC data source option. | Fields for host and full path input become active. |
| 2 | Provide a custom data source host and full path (e.g., host:Full_Path_to_Dir). | The custom host and path details are saved in the job setup. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: 12.User chooses between standard or custom IC/BC data sources: • standard: ETA, AVNFTP (GFS), GFS004 or • custom: provide data source (e.g., host:Full_Path_to_Dir) or •

### TC-040: Off-Line Job IC/BC Location and Time Period Specification

**Scenario Id:** SCN-040

**Requirement Ids:** ["REQ-029"]

**Priority:** P1

**Preconditions:** ["Job is configured as an off-line job."]

**Test Data:** {"end_time": "2023-10-02T00:00:00Z", "start_time": "2023-10-01T00:00:00Z", "location_type": "directory", "directory_path": "/data/offline/icbc"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Configure an off-line job in Job-Setup. | The system prompts for off-line data source location (MetVault or directory) and time period. |
| 2 | Specify a directory path and set the target start and end time period. | The off-line location and time period parameters are accepted. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: For off-line jobs, the user must specify the data source, i.e., location (MetVault or a directory) and time period. Important note for re-runs, if the
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: • etc. or • For off-line jobs, the user must specify the data source, i.e., location (MetVault or a directory) and time period. Important note

### TC-041: Re-run Job Using MetVault Data Source

**Scenario Id:** SCN-041

**Requirement Ids:** ["REQ-029"]

**Priority:** P1

**Preconditions:** ["Job is designated as a re-run for a cycle in the past."]

**Test Data:** {"job_type": "re-run", "cycle_time": "2023-01-15T12:00:00Z", "location_type": "MetVault"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Select a past cycle time, mark the job as a re-run, and specify MetVault as the off-line location. | The job setup establishes MetVault as the input source for the historical cycle. |
| 2 | Request input data retrieval from MetVault for the re-run cycle. | MetVault returns the exact data that was available and used during that specific cycle. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: For off-line jobs, the user must specify the data source, i.e., location (MetVault or a directory) and time period. Important note for re-runs, if the
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: input data is to obtain from the MetVault, then MetVault returns the data that was available and used in that cycle. • TBD: Determine standard
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: • etc. or • For off-line jobs, the user must specify the data source, i.e., location (MetVault or a directory) and time period. Important note
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: for re-runs, if the input data is to obtain from the MetVault, then MetVault returns the data that was available and used in that cycle.

### TC-042: Select Standard vs Custom IC/BC Pre-processor Script

**Scenario Id:** SCN-042

**Requirement Ids:** ["REQ-030"]

**Priority:** P2

**Preconditions:** ["IC/BC data source selection step is completed in Job-Setup."]

**Test Data:** {"custom_script": "/scripts/custom_preproc.sh", "ambiguity_note": "Standard pre-processors are marked TBD."}

| Step | Action | Expected result |
|---|---|---|
| 1 | Navigate to the IC/BC pre-processor selection step. | Options for standard processing and custom script provision are available. |
| 2 | Select standard pre-processing option. | Standard IC/BC pre-processing is configured. |
| 3 | Switch option to supply a custom pre-processing script and provide script reference. | System updates the selection to use the custom IC/BC pre-processing script. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: IC/BC data source and standard pre-processors. 11.Depending on the choice above, user can provide custom IC/BC pre-processor or choose the standard: • standard processing or
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: • provide own pre-processing script

### TC-043: User Responsibility for Custom Assets Residence on Target Clusters

**Scenario Id:** SCN-043

**Requirement Ids:** ["REQ-031"]

**Priority:** P2

**Preconditions:** ["User is submitting a 'custom' GMOD job."]

**Test Data:** {"job_type": "custom GMOD", "custom_assets": ["/cluster/bin/custom_exec", "/cluster/scripts/run.sh"], "target_clusters": ["cluster-A", "cluster-B"]}

| Step | Action | Expected result |
|---|---|---|
| 1 | Configure a 'custom' GMOD job through the Job-Setup module referencing custom scripts and executables. | System allows saving and configuring the custom job setup with MM. |
| 2 | Verify execution workflow expectation for asset presence on the target running cluster(s). | Custom assets are expected to pre-exist on target running cluster(s) as user responsibility. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: Functional Requirements Specification for the Model Manager Page 5 MM's Job-Setup module will allow the user to substitute the default configuration, but it is the
- PDF p. 7, , `p0007-c001-29cf8dd2e122`: user's responsibility to make sure that these scripts, executables, etc. reside on the cluster or clusters where the job will be running on. Submitting a

### TC-044: Run Additional IC/BC Pre-processors Option

**Scenario Id:** SCN-044

**Requirement Ids:** ["REQ-032"]

**Priority:** P1

**Preconditions:** ["User is in Model Manager step for additional IC/BC pre-processor configuration."]

**Test Data:** {"custom_preproc_script": "/usr/local/bin/custom_ldas_adapter.py", "additional_preproc_option": "LDAS"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Select an additional pre-processor such as LDAS for IC/BC data. | System configures LDAS as an additional IC/BC pre-processor. |
| 2 | Change selection to supply a custom pre-processor including a custom pre-processing script. | System configures the provided custom pre-processor script. |
| 3 | Select the option to skip additional IC/BC pre-processing. | System removes additional IC/BC pre-processing steps from the job execution pipeline. |

**Source evidence**

- PDF p. 7, , `p0007-c001-29cf8dd2e122`: • provide own pre-processing script
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Functional Requirements Specification for the Model Manager Page 6 12.User is given the option to run additional pre-processors for the IC/BC data, such as, LDAS
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: or supply own custom pre-processor or skip this option. 13.User chooses between standard and/or custom obs data sources and processing: • Standard: WMO, SAMS, MADIS,

### TC-045: Configure observational data sources and processing

**Scenario Id:** SCN-045

**Requirement Ids:** ["REQ-033"]

**Priority:** P1

**Preconditions:** ["User is navigating the observational data configuration section in Model Manager."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select standard observational data sources (such as WMO, SAMS, MADIS, GTS, RAWS, okmeso, SatWinds, ACARS). | System accepts the selection of standard observational sources. |
| 2 | Provide custom observational sources and custom observational processors. | System allows input and accepts the user-provided custom observational sources and custom observational processors. |
| 3 | Combine both standard observational sources and custom sources/processors in the configuration. | System allows selecting standard sources and/or custom observational sources and processors together. |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: or supply own custom pre-processor or skip this option. 13.User chooses between standard and/or custom obs data sources and processing: • Standard: WMO, SAMS, MADIS,
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: GTS, RAWS, okmeso, SatWinds, ACARS, etc. and/or • provide custom obs source1 and custom obs processor1 • provide custom obs source2 and custom obs processor2

### TC-046: Select compiled standard MM5 executable based on domain size and node count

**Scenario Id:** SCN-046

**Requirement Ids:** ["REQ-034"]

**Priority:** P1

**Preconditions:** ["MM5 model is selectable and prior domain size and node count decisions exist."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Choose the MM5 model after domain size and node count have been set. | System presents compiled standard MM5 executables matching the domain size and node count. |
| 2 | Select one of the presented compiled standard MM5 executables (noting that the exact definition of standard MM5 executable remains TBD). | System successfully assigns the chosen standard MM5 executable to the job configuration. |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: the user: • MM5: The domain size and number of nodes for this job was determined earlier. Based on both choices, the user is presented
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: with different MM5-executables to choose from. These executables have been compiled in advanced. The MM will be able to retrieve the compile info about the
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: executables, e.g., domain size, number of nodes, number of sigma levels, etc. These few executables are standard executables (TBD: determine what 'standard MM5 executable’ means).

### TC-047: Supply user custom executable for MM5 model

**Scenario Id:** SCN-047

**Requirement Ids:** ["REQ-034"]

**Priority:** P2

**Preconditions:** ["MM5 model is selected."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Choose MM5 model and select the option to supply a custom executable. | System displays input field for specifying the user's custom executable location. |
| 2 | Specify the custom executable's cluster location path. | System saves the cluster location path for the custom MM5 executable. |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Or, the user can also supply own executable, e.g., its location on the cluster • WRF: User defines model options (TBD: determine possible model options)

### TC-048: Define model options for WRF model

**Scenario Id:** SCN-048

**Requirement Ids:** ["REQ-035"]

**Priority:** P2

**Preconditions:** ["User is selecting model options in Model Manager."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select the WRF model in Model Manager. | System presents WRF model option configuration interface. |
| 2 | Define WRF model options (acknowledging specific WRF model options are TBD). | System stores the defined model options for the WRF model. |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Or, the user can also supply own executable, e.g., its location on the cluster • WRF: User defines model options (TBD: determine possible model options)

### TC-049: Configure Final Analysis run option

**Scenario Id:** SCN-049

**Requirement Ids:** ["REQ-036"]

**Priority:** P2

**Preconditions:** ["Job context is configured (e.g., re-run or case study context where applicable)."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Navigate to analysis options during job setup (applicable to re-runs and case studies). | System displays option to enable or disable Final Analysis. |
| 2 | Select 'yes' to run Final Analysis. | System records choice to run Final Analysis. |
| 3 | Select 'no' to skip Final Analysis. | System records choice to not run Final Analysis. |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: 15.User chooses whether or not to run Final Analysis. This may only apply to re-runs and case studies. 16.User chooses whether or not to run

### TC-050: Configure Preliminary Analysis run option

**Scenario Id:** SCN-050

**Requirement Ids:** ["REQ-037"]

**Priority:** P2

**Preconditions:** ["Job context is configured (e.g., re-run or case study context where applicable)."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Navigate to analysis options during job setup (applicable to re-runs and case studies). | System displays option to enable or disable Preliminary Analysis. |
| 2 | Select 'yes' to run Preliminary Analysis. | System records choice to run Preliminary Analysis. |
| 3 | Select 'no' to skip Preliminary Analysis. | System records choice to not run Preliminary Analysis. |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: 15.User chooses whether or not to run Final Analysis. This may only apply to re-runs and case studies. 16.User chooses whether or not to run
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Prelim. Analysis. This may only apply to re-runs and case studies. 17.User chooses whether or not run additional processing on the model output. (TBD: What

### TC-051: Configure additional processing on model output

**Scenario Id:** SCN-051

**Requirement Ids:** ["REQ-038"]

**Priority:** P2

**Preconditions:** ["Model output options step is active."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Access model output configuration stage. | System displays choice for running additional processing on model output. |
| 2 | Choose to run additional processing on model output (exact options TBD, e.g., Bias Correction). | System registers selection to execute additional processing. |
| 3 | Choose not to run additional processing on model output. | System registers selection to bypass additional processing. |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: Prelim. Analysis. This may only apply to re-runs and case studies. 17.User chooses whether or not run additional processing on the model output. (TBD: What
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: exactly are the options for additional processing? Bias Correction?) 18.User can choose to save the model output in MetVault. If 'yes', user must specify what

### TC-052: Save model output in MetVault with file specification requirement

**Scenario Id:** SCN-052

**Requirement Ids:** ["REQ-039"]

**Priority:** P1

**Preconditions:** ["Job output save options are accessible."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select 'yes' for saving model output in MetVault. | System enables requirement to specify which output file is to be sent to MetVault. |
| 2 | Attempt to proceed without specifying an output file. | System rejects submission or prompts user that an output file specification is required when 'yes' is selected. |
| 3 | Specify the target output file (e.g., member and/or ensemble output file) and confirm. | System accepts the selection and saves the MetVault destination configuration. |
| 4 | Select 'no' for saving model output in MetVault. | System does not require output file specification for MetVault. |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: exactly are the options for additional processing? Bias Correction?) 18.User can choose to save the model output in MetVault. If 'yes', user must specify what
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: output file is to be sent to the MetVault. 19.User is given the option to save and submit the job now. Submitting now, would run
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: chooses whether or not run additional processing on the model output. (TBD: Is 10. applicable to ClimoFDDA jobs? 11.User can choose to save the model
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: output in MetVault. If 'yes', user must specify what output, e.g., member and/or ensemble output is to be send to the MetVault. 12.User is given

### TC-053: Save and submit job immediately without post-processing

**Scenario Id:** SCN-053

**Requirement Ids:** ["REQ-040"]

**Priority:** P1

**Preconditions:** ["Job setup parameters for IC/BC, observational data, and model options are configured."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select the option to save and submit the job immediately ('now'). | System accepts immediate job submission. |
| 2 | Observe the execution pipeline of the submitted job. | Job executes IC/BC-data processing, observational processing, and model execution. |
| 3 | Verify execution components for post-processing steps. | Post-processing is not executed for this immediate submission. |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: output file is to be sent to the MetVault. 19.User is given the option to save and submit the job now. Submitting now, would run
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: IC/BC-data and obs processing and the model, no post-processing. 20.User chooses whether or not to run post-processing. If ‘yes', then s/he will go through the

### TC-054: Select ClimoFDDA job setup from new model job options

**Scenario Id:** SCN-054

**Requirement Ids:** ["REQ-044"]

**Priority:** P1

**Preconditions:** ["User is logged on to the system."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Log on to the system as a user and navigate to 'Submit a new job' -&gt; 'Set up a new model job'. | The system presents two options: 'Weather FDDA' and 'Climo'. |
| 2 | Select 'Climo' ('Set up a Climo Job' / ClimoFDDA support). | The system initiates the ClimoFDDA job setup workflow. |

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: Functional Requirements Specification for the Model Manager Page 7 The objective of this feature is to integrate the GCAT functionalities within the MM. Suppose the
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: user is logged on to the system and has made the following choices “Submit a new job” -&gt; “Set up a new model job”. S/he
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: is then presented with two more options: “ Weather FDDA” and “Climo”. Primary actor: Meteorologist, software engineer Goal: Set up and run a ClimoFDDA job.
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: At this point, the MM only supports “ClimoFDDA”. Action Sequence: 1. Chooses to “Set up a Climo Job”. 2. User defines a JOBID. 3. User

### TC-055: Configure ClimoFDDA identification, domain, and location parameters

**Scenario Id:** SCN-055

**Requirement Ids:** ["REQ-045"]

**Priority:** P1

**Preconditions:** ["User has initiated ClimoFDDA job setup."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Define a JOBID in the ClimoFDDA setup interface. | The JOBID is accepted and displayed. |
| 2 | Supply other job parameters and determine the domain location. | Job parameters and domain location are configured. |
| 3 | Specify locations for pseudo-obs and custom cross sections. | Locations for pseudo-obs and custom cross sections are accepted. (Note: Unresolved ambiguity whether pseudo-obs and custom cross section locations are only used during post-processing). |

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: At this point, the MM only supports “ClimoFDDA”. Action Sequence: 1. Chooses to “Set up a Climo Job”. 2. User defines a JOBID. 3. User
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: supplies other job parameters. For details, see GCAT tool 4. User determines the domain location. 5. User can specify locations for pseudo-obs and custom cross
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: sections. (TBD: Is this configuration information that is only used during post-processing?) 6. User picks a pre-configured MM5 setup 7. User sets the time line

### TC-056: Configure MM5 setup model and job timeline

**Scenario Id:** SCN-056

**Requirement Ids:** ["REQ-046"]

**Priority:** P1

**Preconditions:** ["User is in the ClimoFDDA job setup workflow."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Pick a pre-configured MM5 setup from the selection options. | The selected pre-configured MM5 setup is applied to the job. |
| 2 | Set the job timeline by specifying start time, end time, and target years. | The start time, end time, and target years are set and displayed accurately in the timeline configuration. |

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: sections. (TBD: Is this configuration information that is only used during post-processing?) 6. User picks a pre-configured MM5 setup 7. User sets the time line
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: for the job: start time, end time and what years 8. User sets the ensemble options: • hourly (TBD: Are there other options? Daily?) •

### TC-057: Configure ClimoFDDA ensemble options

**Scenario Id:** SCN-057

**Requirement Ids:** ["REQ-047"]

**Priority:** P1

**Preconditions:** ["User is in the ClimoFDDA job setup workflow."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select hourly frequency for ensemble options. | Hourly frequency is set. (Note: Unresolved ambiguity whether additional frequency options like daily exist beyond hourly). |
| 2 | Select statistical measures including min, max, mean, and standard deviation. | Statistical measures (min, max, mean, standard deviation, etc.) are successfully selected. |
| 3 | Select diurnal cycle and typical moment ensemble options. | Diurnal cycle and typical moment options are enabled and configured. |

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: for the job: start time, end time and what years 8. User sets the ensemble options: • hourly (TBD: Are there other options? Daily?) •
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: min, max, mean, standard deviation,.... • diurnal cycle • typical moment 9. User can request the number of nodes this job should run on. 10.User

### TC-058: Request cluster nodes for ClimoFDDA job

**Scenario Id:** SCN-058

**Requirement Ids:** ["REQ-048"]

**Priority:** P2

**Preconditions:** ["User is in the ClimoFDDA job setup workflow."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Enter and submit a request for the desired number of cluster nodes (e.g., 4 nodes). | The system accepts and saves the requested node count for the job. |

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: min, max, mean, standard deviation,.... • diurnal cycle • typical moment 9. User can request the number of nodes this job should run on. 10.User

### TC-059: Opt to run post-processing and proceed to section 3.4 action sequence

**Scenario Id:** SCN-059

**Requirement Ids:** ["REQ-041"]

**Priority:** P1

**Preconditions:** ["User is configuring post-processing options in the setup workflow."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select 'yes' when prompted whether or not to run post-processing. | The system proceeds to the section 3.4 action sequence. (Note: Unresolved ambiguity regarding the level of post-processing customization needed for RAL vs ranges users). |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: IC/BC-data and obs processing and the model, no post-processing. 20.User chooses whether or not to run post-processing. If ‘yes', then s/he will go through the
- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: action sequence in 3.4. (TBD: How customizable should post-processing be? In GCAT, e.g., the user can specify locations for pseudo-soundings, cross sections, pseudo-obs, etc. Do

### TC-060: Opt out of post-processing run

**Scenario Id:** SCN-060

**Requirement Ids:** ["REQ-041"]

**Priority:** P1

**Preconditions:** ["User is configuring post-processing options in the setup workflow."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select 'no' when prompted whether or not to run post-processing. | The system records that post-processing will not be run and does not proceed to the section 3.4 action sequence. |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: IC/BC-data and obs processing and the model, no post-processing. 20.User chooses whether or not to run post-processing. If ‘yes', then s/he will go through the

### TC-061: Save job configuration to file

**Scenario Id:** SCN-061

**Requirement Ids:** ["REQ-042"]

**Priority:** P2

**Preconditions:** ["Job parameters have been configured in Model Manager."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Trigger the save job configuration option and select a target file destination. | The job configuration is successfully saved to the specified file. |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: pre-configured post-processing options be sufficient?) 21.User can save the above job configuration. Job configurations can be saved to a file. 22.User submits the job. Use

### TC-062: Submit job

**Scenario Id:** SCN-062

**Requirement Ids:** ["REQ-043"]

**Priority:** P1

**Preconditions:** ["Job configuration is complete."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Click the submit button to submit the job. | The job submission request is processed and accepted by the system. |

**Source evidence**

- PDF p. 8, , `p0008-c001-c4f8c7dd513d`: pre-configured post-processing options be sufficient?) 21.User can save the above job configuration. Job configurations can be saved to a file. 22.User submits the job. Use

### TC-063: Select Set up a Climo Job during ClimoFDDA setup

**Scenario Id:** SCN-063

**Requirement Ids:** ["REQ-052"]

**Priority:** P2

**Preconditions:** ["User is logged on to the system and in the Model Manager interface."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Navigate to the Model Manager job setup screen after selecting 'Submit a new job' -&gt; 'Set up a new model job' and choosing 'Climo'. | The option to 'Set up a Climo Job' is displayed and available for selection. |
| 2 | Select the option to 'Set up a Climo Job'. | The system accepts the selection and proceeds with the ClimoFDDA job configuration workflow. |

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: At this point, the MM only supports “ClimoFDDA”. Action Sequence: 1. Chooses to “Set up a Climo Job”. 2. User defines a JOBID. 3. User

### TC-064: Configure model output additional processing option for ClimoFDDA job

**Scenario Id:** SCN-064

**Requirement Ids:** ["REQ-049"]

**Priority:** P2

**Preconditions:** ["User has initiated 'Set up a Climo Job' in ClimoFDDA setup."]

**Test Data:** {"applicability_status": "Applicability of model output additional processing to ClimoFDDA jobs is TBD."}

| Step | Action | Expected result |
|---|---|---|
| 1 | During ClimoFDDA job setup, navigate to the model output options. | The system presents the option to choose whether or not to run additional processing on the model output. |
| 2 | Toggle the option to run additional processing on model output (or choose 'no'). | The user choice is updated in the job setup interface, noting that applicability of model output additional processing to ClimoFDDA jobs is TBD. |

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: chooses whether or not run additional processing on the model output. (TBD: Is 10. applicable to ClimoFDDA jobs? 11.User can choose to save the model

### TC-065: Save and submit ClimoFDDA job immediately without post-processing

**Scenario Id:** SCN-065

**Requirement Ids:** ["REQ-050"]

**Priority:** P1

**Preconditions:** ["User has configured base parameters (JOBID, time line, ensemble options) for a ClimoFDDA job."]

| Step | Action | Expected result |
|---|---|---|
| 1 | During ClimoFDDA job setup, select the option to save and submit the job immediately without configuring post-processing. | The system accepts the immediate save and submit request. |
| 2 | Confirm submission and verify the scheduled execution plan for the job. | The job is submitted and configured to run member models, the ensemble, and possible model output processing, but no post-processing. |

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: the option to save and submit the job now. Submitting now, would run the member models, the ensemble, and possible model output processing, no post-
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: processing. 13.User chooses whether or not to run post-processing on the ensemble output. If “yes', then s/he will be presented with the following options: •

### TC-066: Configure ensemble output post-processing products and destination specifications

**Scenario Id:** SCN-066

**Requirement Ids:** ["REQ-051"]

**Priority:** P1

**Preconditions:** ["User is in the post-processing section of ClimoFDDA job setup."]

**Test Data:** {"products": ["Plots (NCL or RIP)", "NAPS", "MDV", "Sites", "MEDOC (1-4)", "Raster", "PRF", "Wind Roses"], "destination_host": "remote.server.org", "destination_location": "/outputs/climo/ensemble_postproc/"}

| Step | Action | Expected result |
|---|---|---|
| 1 | In ClimoFDDA job setup, select 'yes' to run post-processing on the ensemble output. | The system presents post-processing product options including Plots (NCL or RIP), NAPS, MDV, Sites, MEDOC (1–4), Raster, PRF, and Wind Roses. |
| 2 | Select products (e.g., Plots [NCL or RIP], NAPS, MDV) and specify a destination host and destination location path for each output product file. | The system prompts for and saves the specified destination host and location for each selected output product file. |

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: processing. 13.User chooses whether or not to run post-processing on the ensemble output. If “yes', then s/he will be presented with the following options: •
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: Plots (NCL or RIP) • NAPS • MDV • Sites • MEDOC (1 – 4) (?) • Raster • PRF • Wind Roses • ...
- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: For each output product, the user is prompted to supply a destination host and location, where the output files should be copied.

### TC-067: Decline post-processing on ensemble output

**Scenario Id:** SCN-067

**Requirement Ids:** ["REQ-051"]

**Priority:** P2

**Preconditions:** ["User is in the post-processing section of ClimoFDDA job setup."]

| Step | Action | Expected result |
|---|---|---|
| 1 | In ClimoFDDA job setup, select 'no' when prompted whether to run post-processing on ensemble output. | The system does not present product options (Plots, NAPS, MDV, etc.) or prompt for destination host and location for ensemble post-processing files. |

**Source evidence**

- PDF p. 9, • NAPS, `p0009-c001-80cd4f07468c`: processing. 13.User chooses whether or not to run post-processing on the ensemble output. If “yes', then s/he will be presented with the following options: •

### TC-068: Specify post-processing settings for member models output

**Scenario Id:** SCN-068

**Requirement Ids:** ["REQ-053"]

**Priority:** P2

**Preconditions:** ["User is in the Job Setup interface."]

**Test Data:** {"year_output": "Year 1", "post_processor": "RIP", "target_location": "/data/members/postproc_output"}

| Step | Action | Expected result |
|---|---|---|
| 1 | In Job Setup, select to enable post-processing for members' output. | Fields for specifying year-output, post-processor selection, and output copy location are displayed. |
| 2 | Specify which year-output to post-process, select post-processor(s), and enter the destination directory path where output files should be copied. | The system saves the member output post-processing selections and path configurations. |

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: Functional Requirements Specification for the Model Manager Page 8 14.The user can also specify whether the members' output should be post-processed. S/he can specify which
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: year-output to post-process and what post-processor(s) to use and where the output files should be copied. 15. The user can specify whether another process (coupled

### TC-069: Specify coupled application execution on post-process output products

**Scenario Id:** SCN-069

**Requirement Ids:** ["REQ-054"]

**Priority:** P2

**Preconditions:** ["User is in Job Setup with post-processing options active."]

**Test Data:** {"ambiguity_note": "Needs further clarification."}

| Step | Action | Expected result |
|---|---|---|
| 1 | In Job Setup, navigate to the post-process output products configuration section. | An option to specify whether another process (coupled app) should be run on post-process output products is displayed. |
| 2 | Select and configure the coupled application option to run on post-process output products. | The system records the coupled app setting, noting that this capability needs further clarification. |

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: year-output to post-process and what post-processor(s) to use and where the output files should be copied. 15. The user can specify whether another process (coupled
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: app) should be run on the post-process output products. This needs further clarification. 16.User can save the above job configuration. Job configurations can be saved

### TC-070: Save job configuration to a file

**Scenario Id:** SCN-070

**Requirement Ids:** ["REQ-055"]

**Priority:** P2

**Preconditions:** ["User is in Job Setup with an active configuration."]

**Test Data:** {"file_path": "/configs/climo_job_config.xml"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Complete desired job configuration parameters in Job Setup. | Job configuration parameters are populated. |
| 2 | Execute the command to save the job configuration to a file, providing a valid filename. | The system successfully saves the job configuration details into the specified file. |

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: app) should be run on the post-process output products. This needs further clarification. 16.User can save the above job configuration. Job configurations can be saved
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: to a file. 17.User submits the job. Use Case “CAM”: Setting up a CAM job TBD 3.2 Set up and submit a “post-processing” job The

### TC-071: Submit configured post-processing job

**Scenario Id:** SCN-071

**Requirement Ids:** ["REQ-056"]

**Priority:** P1

**Preconditions:** ["Job setup parameters are fully configured."]

| Step | Action | Expected result |
|---|---|---|
| 1 | In Job Setup, select the submit option for the configured job. | The system submits the configured job and provides confirmation of submission. |

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: to a file. 17.User submits the job. Use Case “CAM”: Setting up a CAM job TBD 3.2 Set up and submit a “post-processing” job The

### TC-072: Set up and submit post-processing job using future FDDA-job output

**Scenario Id:** SCN-072

**Requirement Ids:** ["REQ-057", "REQ-058", "REQ-059", "REQ-060", "REQ-061", "REQ-062", "REQ-063", "REQ-064"]

**Priority:** P2

**Preconditions:** ["User is logged on to the Model Manager system and has initiated job creation."]

**Test Data:** {"nodes": 4, "job_id": "FDDA_JOB_1234", "cycle_time": "2023-10-25T12:00:00Z", "config_type": "custom", "config_file_path": "/configs/custom_ncl.cfg", "destination_location": "/output/products/fdda_post/", "post_processing_type": "Plots (NCL)", "saved_settings_filepath": "/user/jobs/saved_postproc_job1.json"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Select 'Set up a new 'post-processing' job'. | The user is prompted to supply location and name of the model output file. |
| 2 | Select the option for a file that will be produced by a running or scheduled FDDA-job and enter the JOBID and cycle time. | The JOBID and cycle time are accepted for the future model output file. |
| 3 | Select post-processing types from options including Plots (NCL or RIP), NAPS, MDV, Sites, MEDOC (1 – 4) (?), Stereo, or Verification. | The chosen post-processing options are selected (preserving source ambiguity 'MEDOC (1 – 4) (?)'). |
| 4 | Supply a custom configuration file for a chosen option or choose to use the default configuration file. | The specified custom or default configuration file settings are applied to the chosen post-processing options. |
| 5 | Specify the destination location for the output products. | The destination location is recorded. |
| 6 | Specify the number of nodes this post-processing job should run on (noting TBD: Is this a correct requirement?). | The number of nodes value is entered and registered. |
| 7 | Save the post-processing job settings to a file. | Job configurations are successfully saved to a file. |
| 8 | Submit the post-processing job. | The post-processing job is submitted successfully. |

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: new job”. Primary actor: Meteorologist, software engineer Goal: Run post-processing on model output Action Sequence: 1. User selects “Set up a new 'post-processing' job” .
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: 2. User is prompted to supply location and name of the model output file: • If the model output file will be produced by a
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: running or scheduled FDDA-job, then the user supplies JOBID &amp; cycle time • If the model output file already exists, then the user supplies its
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: location. 3. User chooses the type of post-processing: • Plots (NCL or RIP) • NAPS • MDV • Sites • MEDOC (1 – 4) (?)
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: • Stereo • Verification 4. For each of the options chosen in 3., the user can supply a custom configuration file (if this is applicable)
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: or use the default configuration file. 5. User must supply destination location for the output products. 6. User can specify the number of nodes this
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: job should run on (TBD: Is this a correct requirement?) 7. User can save this job's setting. Job configurations can be saved to a file.
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: Functional Requirements Specification for the Model Manager Page 9 8. User submits job. 3.3 Submit a 'By-hand' job The objective of this feature is to

### TC-073: Set up post-processing job using an existing model output file with default configurations

**Scenario Id:** SCN-073

**Requirement Ids:** ["REQ-057", "REQ-058", "REQ-059", "REQ-060", "REQ-061", "REQ-064"]

**Priority:** P2

**Preconditions:** ["User is logged on to the system and an existing model output file is available at a reachable path."]

**Test Data:** {"config_type": "default", "destination_location": "/output/products/existing_run_post/", "post_processing_types": ["Verification", "MDV"], "existing_file_location": "/data/models/output_run_01.nc"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Select 'Set up a new 'post-processing' job'. | The system prompts for model output file details. |
| 2 | Specify that the file already exists and enter its file location. | The location of the existing model output file is accepted. |
| 3 | Select post-processing types (e.g., Verification and MDV). | The post-processing types are selected. |
| 4 | Select the option to use the default configuration file for each selected post-processing option. | Default configuration settings are attached to the options. |
| 5 | Enter the required destination location for the output products. | Destination location is validated and saved. |
| 6 | Submit the post-processing job without saving settings or changing node count. | The job is submitted successfully. |

**Source evidence**

- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: new job”. Primary actor: Meteorologist, software engineer Goal: Run post-processing on model output Action Sequence: 1. User selects “Set up a new 'post-processing' job” .
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: 2. User is prompted to supply location and name of the model output file: • If the model output file will be produced by a
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: running or scheduled FDDA-job, then the user supplies JOBID &amp; cycle time • If the model output file already exists, then the user supplies its
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: location. 3. User chooses the type of post-processing: • Plots (NCL or RIP) • NAPS • MDV • Sites • MEDOC (1 – 4) (?)
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: • Stereo • Verification 4. For each of the options chosen in 3., the user can supply a custom configuration file (if this is applicable)
- PDF p. 10, TBD, `p0010-c001-ad258d385d69`: or use the default configuration file. 5. User must supply destination location for the output products. 6. User can specify the number of nodes this
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: Functional Requirements Specification for the Model Manager Page 9 8. User submits job. 3.3 Submit a 'By-hand' job The objective of this feature is to

### TC-074: Complete creation, saving, submission, queue view, and email notification flow for a By-hand job

**Scenario Id:** SCN-074

**Requirement Ids:** ["REQ-065", "REQ-066", "REQ-067", "REQ-068", "REQ-069", "REQ-070", "REQ-071"]

**Priority:** P1

**Preconditions:** ["User is logged on to the system and has selected 'Submit a new job'."]

**Test Data:** {"additional_information": "Routine execution", "estimated_time": "02:00:00", "executables": "run_model.sh", "frequency": "Daily", "job_id": "GMUAE", "job_type": "Custom", "location_of_output_products": "host:/dir_path", "location_of_script": "host:/full_path_to_script", "max_runtime": "03:00:00", "number_of_nodes": "4", "time_when_to_run": "2023-10-25 12:00"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Select 'Submit a 'By Hand' Job' from the job submission options. | The 'By Hand' job entry form is displayed. |
| 2 | Enter mandatory details: Job ID 'GMUAE', script location 'host:/full_path_to_script', run time '2023-10-25 12:00', estimated runtime '02:00:00', executable 'run_model.sh', max runtime '03:00:00', node count '4', output location 'host:/dir_path'. | All mandatory job parameters are populated. |
| 3 | Enter optional details: run frequency 'Daily', job type 'Custom', additional info 'Routine execution', and enable email notification for job status changes. | All optional job parameters and notification settings are configured. |
| 4 | Save the 'By-hand' job settings to a file. | The job configuration file is saved successfully. |
| 5 | Submit the 'By-hand' job. | The job is registered and submitted successfully. |
| 6 | Navigate to the job queue view and observe the job state through execution. | The submitted job is visible in the queue, and email notifications are received when the job is started, finished, or killed. |

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: User can view his/her job in the job queue (see 3.1.). 6. User can receive an email notification when job is started, finished or killed.

### TC-075: Verification of Custom job completion notification to Model Manager

**Scenario Id:** SCN-075

**Requirement Ids:** ["REQ-072"]

**Priority:** P1

**Preconditions:** ["A 'custom' job is submitted and actively running on the system."]

**Test Data:** {"job_type": "custom"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Execute a submitted 'custom' job and allow it to complete its execution. | The custom job reaches the 'done' state. |
| 2 | Inspect the communication logs and Model Manager status updates upon job completion. | The custom job notifies the Model Manager that it is done. |

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: (SRS Note: 'custom' job will need to notify the MM when done.) 3.4 Load a job configuration from a file and submit the job The

### TC-076: Load, modify, save, and submit a job configuration file

**Scenario Id:** SCN-076

**Requirement Ids:** ["REQ-073", "REQ-074", "REQ-075", "REQ-076", "REQ-077"]

**Priority:** P2

**Preconditions:** ["The user is logged on to the system."]

**Test Data:** {"file_name": "job_config_sample.json"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Select 'Submit a job configuration file' option after logging into Model Manager. | The option to submit a job configuration file is selected. |
| 2 | Supply a valid file name to load the job configuration into MM. | The job configuration file is loaded into MM successfully. |
| 3 | Modify the loaded job configuration settings. | The changes are applied to the loaded job configuration. |
| 4 | Save the changed job configuration. | The modified job configuration is saved. |
| 5 | Submit the job based on the loaded/modified job configuration. | The job is submitted successfully. |

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: to the system and has made the following choice, “Submit a new job”. Primary actor: Meteorologist, software engineer Action Sequence: 1. User selects ”Submit a
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: ”Submit a job configuration file”.
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: Functional Requirements Specification for the Model Manager Page 10 2. User supplies file name to load. 3. User can make changes to the configuration. 4.
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: User can save the changed configuration. 5. User submits the job. 3.5 Retrieve and run a previously saved job configuration The objective of this feature
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: job configuration. 4. User changes the job configuration. 5. User can save the changed job configuration. 6. User submits job. 3.6 View scheduled, running and

### TC-077: Log on, view previously saved job configurations table, select, modify, and delete a job configuration

**Scenario Id:** SCN-077

**Requirement Ids:** ["REQ-078", "REQ-079", "REQ-080"]

**Priority:** P2

**Preconditions:** ["At least one previously saved job configuration exists for the user."]

**Test Data:** {"user_id": "test_user", "password": "valid_password"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Log on to Model Manager using valid user ID and password. | User logs on successfully. |
| 2 | Choose to view previously saved job configurations. | A table of saved job configurations is displayed, which may include attributes such as Job id, Job type, Cycle time that was run last (if applicable), and time this job was run last. |
| 3 | Select a job configuration from the table and edit its settings. | The selected job configuration is updated with the new changes. |
| 4 | Select a job configuration from the table and execute delete action. | The selected job configuration is deleted. |

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: actor: Meteorologist, software engineer Goal: Run a previously configured job. Action Sequence: 1. User logs on with user id/password. 2. User chooses to look at
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: his/her previously saved job configurations. A table of saved jobs may include the following attributes: • Job id • Job type • Cycle time that
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: was run last (if applicable) • time this job was run last • ... 3. User selects a job. User can change or delete this
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: job configuration. 4. User changes the job configuration. 5. User can save the changed job configuration. 6. User submits job. 3.6 View scheduled, running and

### TC-078: Submit job from retrieved or changed job configuration

**Scenario Id:** SCN-078

**Requirement Ids:** ["REQ-081"]

**Priority:** P2

**Preconditions:** ["User is logged into the Model Manager system.", "Saved job configurations exist for the user."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Retrieve a saved job configuration. | The saved job configuration is displayed. |
| 2 | Submit the job directly without making changes. | The job is submitted successfully based on the retrieved configuration. |
| 3 | Retrieve another saved job configuration and modify one or more fields. | The job configuration reflects the modified values. |
| 4 | Submit the modified job configuration. | The job is submitted successfully with the updated configuration. |

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: job configuration. 4. User changes the job configuration. 5. User can save the changed job configuration. 6. User submits job. 3.6 View scheduled, running and

### TC-079: Log on to monitor running, scheduled, or past jobs

**Scenario Id:** SCN-079

**Requirement Ids:** ["REQ-082"]

**Priority:** P2

**Preconditions:** ["User account exists with valid credentials."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Navigate to the Model Manager logon interface. | Logon prompt requiring user ID and password is displayed. |
| 2 | Enter valid user ID and password, then submit. | User is authenticated and granted access to view running jobs, job queue, or past jobs. |

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: past. Primary actor: Meteorologist, software engineer Goal: Monitor a running job and view scheduled and old jobs Action Sequence: 1. User logs on with user
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: id/password. 2. User chooses to look at all running jobs, all scheduled jobs (the job queue), past jobs or all jobs (running, scheduled, old). User

### TC-080: Select job viewing options for running, scheduled, past, or all jobs

**Scenario Id:** SCN-080

**Requirement Ids:** ["REQ-083"]

**Priority:** P2

**Preconditions:** ["User is logged on to the job viewing interface.", "Jobs in running, scheduled, and completed states exist in the system."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select the option to view all running jobs. | The view filters and displays all currently running jobs. |
| 2 | Select the option to view all scheduled jobs (the job queue). | The view filters and displays all scheduled jobs in the queue. |
| 3 | Select the option to view past jobs. | The view filters and displays all jobs that ran in the past. |
| 4 | Select the option to view all jobs (running, scheduled, old). | The view displays all running, scheduled, and past jobs together. |

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: id/password. 2. User chooses to look at all running jobs, all scheduled jobs (the job queue), past jobs or all jobs (running, scheduled, old). User
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: selects one of the four options. 3. User is presented with a job table. Depending on the user's choice in 2, the job table may

### TC-081: Display job table with user ID owner attribute

**Scenario Id:** SCN-081

**Requirement Ids:** ["REQ-084"]

**Priority:** P2

**Preconditions:** ["User is logged on to the job viewing section."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select a job viewing option from the available choices. | A job table is presented. |
| 2 | Inspect the table columns and entries for job ownership. | The job table presents attributes including the user ID identifying the owner of each job. |

**Source evidence**

- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: selects one of the four options. 3. User is presented with a job table. Depending on the user's choice in 2, the job table may
- PDF p. 12, 3.5 Retrieve and run a previously saved job configuration, `p0012-c001-984984f2dea2`: present the following attributes to the user: • user id – the 'owner' of the job

### TC-082: Identify clusters, setup, and register custom job for By-hand submission

**Scenario Id:** SCN-082

**Requirement Ids:** ["REQ-085"]

**Priority:** P1

**Preconditions:** ["User has access credentials to target cluster machines and Model Manager."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Identify the target cluster(s) where the custom job should run. | Target cluster(s) are selected. |
| 2 | Log on to the identified target machine/cluster. | Session on the target machine is successfully established. |
| 3 | Perform the operations necessary for setting up the job. | Job setup operations complete on the target machine. |
| 4 | Register the job with the Model Manager. | Custom job is successfully registered with the MM. |

**Source evidence**

- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: accommodate the current GMOD-framework. It will also give the user the ability to run customized jobs. In order to submit a custom job to the
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: MM, the user must first identify the cluster(s), where his/her job should run on. Then, log on to this machine, perform operations that are necessary
- PDF p. 11, 3.3 Submit a 'By-hand' job, `p0011-c001-b1a8090b0217`: for setting up the job and then register the job with the MM (see Action Sequence below). It is important to note that since a

### TC-083: Display complete set of standard job attributes in Model Manager

**Scenario Id:** SCN-083

**Requirement Ids:** ["REQ-086"]

**Priority:** P1

**Preconditions:** ["Jobs of various types and states are present in the system.", "User is logged into Model Manager."]

**Test Data:** {"job_types": ["GMOD", "climoFDDA", "FDDA-re-run", "case study", "custom"], "job_stages": ["Pre-processing", "F-analysis", "Prelim. Analysis"], "job_statuses": ["SCHEDULED", "RUNNING", "DONE"]}

| Step | Action | Expected result |
|---|---|---|
| 1 | View the presented jobs in Model Manager for jobs across various states (SCHEDULED, RUNNING, status in %, DONE) and types (e.g. GMOD, climoFDDA, FDDA-re-run, case study, custom). | Model Manager displays Job id, Job type, Job priority, start time, remaining time (estimated) or time taken, cycle (if applicable), stage (Pre-processing, F-analysis, Prelim. Analysis, etc.), status (SCHEDULED, RUNNING, status in % - if applicable, DONE), cluster and nodes (for running jobs), and number of processors (along with unspecified 'and others' attributes). |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: Functional Requirements Specification for the Model Manager Page 11 • Job id • Job type – such as: GMOD, climoFDDA, FDDA-re-run, case study, custom,.... •
- PDF p. 13, , `p0013-c001-139ddec67a27`: Job priority (TBD: How should jobs be prioritized?) • start time • remaining time (estimated) or time it took to run the job • cycle
- PDF p. 13, , `p0013-c001-139ddec67a27`: (if applicable) • stage (Pre-processing, F-analysis, Prelim. Analysis,...) • status ( SCHEDULED, RUNNING, status in % - if applicable, DONE) • cluster and nodes (for
- PDF p. 13, , `p0013-c001-139ddec67a27`: a running job) • number of processors • and others 4. User can select a job and receive more detailed information (TBD: What exactly are

### TC-084: Select job to view detailed information

**Scenario Id:** SCN-084

**Requirement Ids:** ["REQ-087"]

**Priority:** P2

**Preconditions:** ["User is viewing the job list in Model Manager."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select a specific job from the displayed job list. | Detailed information for the selected job is displayed to the user. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: a running job) • number of processors • and others 4. User can select a job and receive more detailed information (TBD: What exactly are
- PDF p. 13, , `p0013-c001-139ddec67a27`: the details?) 5. User can look at a jobs log files. 6. User can delete his/her jobs from the job queue. A “super user” can

### TC-085: View log files of a job

**Scenario Id:** SCN-085

**Requirement Ids:** ["REQ-088"]

**Priority:** P2

**Preconditions:** ["User is logged into Model Manager and viewing job details or options.", "Log files exist for the target job."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Select a job and choose the option to view its log files. | The log files corresponding to the selected job are displayed. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: the details?) 5. User can look at a jobs log files. 6. User can delete his/her jobs from the job queue. A “super user” can

### TC-086: Standard User Delete Own Job from Queue

**Scenario Id:** SCN-086

**Requirement Ids:** ["REQ-089"]

**Priority:** P1

**Preconditions:** ["A standard user exists with an owned job currently in the job queue."]

**Test Data:** {"job_id": "Job A", "job_owner": "Standard User", "user_role": "Standard User"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in as a standard user who owns Job A in the job queue. | User is logged in and Job A is displayed in the job queue under their ownership. |
| 2 | Select Job A and issue the command to delete it from the job queue. | Job A is successfully removed from the job queue. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: the details?) 5. User can look at a jobs log files. 6. User can delete his/her jobs from the job queue. A “super user” can

### TC-087: Super User Delete Any Job from Queue

**Scenario Id:** SCN-087

**Requirement Ids:** ["REQ-089"]

**Priority:** P1

**Preconditions:** ["A super user exists.", "A job (Job B) owned by a standard user exists in the job queue."]

**Test Data:** {"job_id": "Job B", "job_owner": "Standard User", "user_role": "Super User"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in as a super user. | Super user is logged in and can view all user jobs in the job queue. |
| 2 | Select Job B (owned by another user) from the job queue and issue the command to delete it. | Job B is successfully removed from the job queue by the super user. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: the details?) 5. User can look at a jobs log files. 6. User can delete his/her jobs from the job queue. A “super user” can
- PDF p. 13, , `p0013-c001-139ddec67a27`: delete any job from the job queue. 7. User can stop his/her running job. A “super user” can stop any running job. 8. User can

### TC-088: Standard User Stop Own Running Job

**Scenario Id:** SCN-088

**Requirement Ids:** ["REQ-090"]

**Priority:** P1

**Preconditions:** ["A standard user exists with a job in the RUNNING state."]

**Test Data:** {"job_id": "Job C", "job_owner": "Standard User", "user_role": "Standard User", "initial_state": "RUNNING"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in as a standard user who has a job (Job C) in the RUNNING state. | User is logged in and Job C is shown with status RUNNING. |
| 2 | Select Job C and execute the stop command. | Job C transitions out of the RUNNING state to stopped. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: delete any job from the job queue. 7. User can stop his/her running job. A “super user” can stop any running job. 8. User can

### TC-089: Super User Stop Any Running Job

**Scenario Id:** SCN-089

**Requirement Ids:** ["REQ-090"]

**Priority:** P1

**Preconditions:** ["A super user exists.", "A running job (Job D) owned by a standard user exists."]

**Test Data:** {"job_id": "Job D", "job_owner": "Standard User", "user_role": "Super User", "initial_state": "RUNNING"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in as a super user and view running jobs. | Super user sees Job D (owned by another user) currently in the RUNNING state. |
| 2 | Select Job D and issue the stop command. | Job D is stopped successfully by the super user. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: delete any job from the job queue. 7. User can stop his/her running job. A “super user” can stop any running job. 8. User can

### TC-090: Standard User Re-start Own Job

**Scenario Id:** SCN-090

**Requirement Ids:** ["REQ-091"]

**Priority:** P1

**Preconditions:** ["A standard user exists with an eligible job (Job E)."]

**Test Data:** {"job_id": "Job E", "job_owner": "Standard User", "user_role": "Standard User"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in as a standard user who owns Job E. | User is logged in and Job E is accessible. |
| 2 | Select Job E and trigger the re-start command. | Job E is re-started. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### TC-091: Super User Re-start Any Job

**Scenario Id:** SCN-091

**Requirement Ids:** ["REQ-091"]

**Priority:** P1

**Preconditions:** ["A super user exists.", "A job (Job F) owned by a standard user exists in the system."]

**Test Data:** {"job_id": "Job F", "job_owner": "Standard User", "user_role": "Super User"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in as a super user. | Super user is logged in and can access all jobs. |
| 2 | Select Job F (owned by another user) and issue the re-start command. | Job F is re-started successfully by the super user. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: delete any job from the job queue. 7. User can stop his/her running job. A “super user” can stop any running job. 8. User can
- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### TC-092: Standard User Resume Own Stopped Job

**Scenario Id:** SCN-092

**Requirement Ids:** ["REQ-092"]

**Priority:** P1

**Preconditions:** ["A standard user exists with an owned job in a stopped state."]

**Test Data:** {"job_id": "Job G", "job_owner": "Standard User", "user_role": "Standard User", "initial_state": "STOPPED"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in as a standard user who owns Job G, which is currently in a stopped state. | User is logged in and Job G is shown in stopped status. |
| 2 | Select Job G and trigger the resume command. | Job G resumes execution. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### TC-093: Super User Resume Any Stopped Job

**Scenario Id:** SCN-093

**Requirement Ids:** ["REQ-092"]

**Priority:** P1

**Preconditions:** ["A super user exists.", "A job (Job H) owned by a standard user exists in a stopped state."]

**Test Data:** {"job_id": "Job H", "job_owner": "Standard User", "user_role": "Super User", "initial_state": "STOPPED"}

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in as a super user. | Super user is logged in and locates Job H (owned by another user) in a stopped state. |
| 2 | Select Job H and issue the resume command. | Job H is successfully resumed by the super user. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### TC-094: Owner Resumes Own Stopped Job Successfully

**Scenario Id:** SCN-094

**Requirement Ids:** ["REQ-092"]

**Priority:** P1

**Preconditions:** ["The job is in a stopped state.", "The logged-in user is the owner of the stopped job."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in as a regular user who owns the stopped job. | User is authenticated and logged in. |
| 2 | Select the owned stopped job and issue the command to resume it. | The job resumes successfully. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### TC-095: Super User Resumes Another User's Stopped Job Successfully

**Scenario Id:** SCN-095

**Requirement Ids:** ["REQ-092"]

**Priority:** P1

**Preconditions:** ["The job is in a stopped state.", "The logged-in user has 'super user' privileges.", "The stopped job is owned by a different user."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in as a user with super user privileges. | Super user is authenticated and logged in. |
| 2 | Select a stopped job owned by another user and issue the command to resume it. | The stopped job owned by the other user resumes successfully. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

### TC-096: Non-Super User Attempting to Resume Another User's Stopped Job is Denied Permission

**Scenario Id:** SCN-096

**Requirement Ids:** ["REQ-092"]

**Priority:** P2

**Preconditions:** ["The job is in a stopped state.", "The logged-in user is a non-super user.", "The stopped job is owned by another user."]

| Step | Action | Expected result |
|---|---|---|
| 1 | Log in as a regular non-super user who does not own the target stopped job. | Non-super user is authenticated and logged in. |
| 2 | Attempt to issue the command to resume the stopped job owned by another user. | Permission is denied and the job is not resumed. |

**Source evidence**

- PDF p. 13, , `p0013-c001-139ddec67a27`: re-start his/her job. A “super user” can re-start any job. 9. User can resume his/her stopped job. A “super user” can resume any stopped job.

